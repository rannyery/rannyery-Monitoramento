
import React from 'react';
import { ShieldCheck, CheckCircle } from 'lucide-react';
import { MonitoredService } from '../types';

interface Props {
  info: {
    hostname: string;
    services: MonitoredService[];
  } | null;
}

const RecoveryAlertModal: React.FC<Props> = ({ info }) => {
  if (!info) return null;

  return (
    <div className="fixed top-10 right-10 z-[120] animate-in fade-in slide-in-from-right-8 duration-500">
      <div className="bg-slate-900 border-l-4 border-emerald-500 rounded-lg shadow-[0_0_30px_-5px_rgb(16,185,129,0.3)] w-full max-w-md overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-emerald-600/10 px-6 py-4 flex items-center gap-4 border-b border-emerald-500/20">
            <div className="bg-emerald-500 p-2 rounded-full shadow-lg shadow-emerald-500/50 animate-bounce">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
                 <h2 className="text-lg font-bold text-emerald-400">Serviço Restabelecido</h2>
                 <p className="text-xs text-slate-400">O sistema detectou recuperação automática.</p>
            </div>
        </div>
        
        <div className="p-5 space-y-4">
          <div className="flex items-center justify-between text-sm">
             <span className="text-slate-400">Servidor:</span>
             <span className="font-mono font-bold text-slate-200 bg-slate-800 px-2 py-0.5 rounded">{info.hostname}</span>
          </div>
          
          <div className="space-y-2">
              {info.services.map(service => (
                  <div key={service.name} className="flex items-center gap-3 p-3 bg-emerald-500/5 rounded-md border border-emerald-500/10">
                      <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                      <div>
                          <p className="font-mono font-medium text-emerald-300 text-sm">{service.name}</p>
                          <p className="text-[10px] text-emerald-400/60 uppercase font-bold tracking-wider">Online</p>
                      </div>
                  </div>
              ))}
          </div>
        </div>
        
        {/* Progress bar visual timer */}
        <div className="h-1 bg-slate-800 w-full">
            <div className="h-full bg-emerald-500 animate-[width_8s_linear_forwards]" style={{width: '100%'}}></div>
        </div>
      </div>
    </div>
  );
};

export default RecoveryAlertModal;
