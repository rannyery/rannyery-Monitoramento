
import React, { useState, useEffect, useRef } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import { isAuthenticated } from '../services/authService';
import { getHosts, getAlerts } from '../services/mockData';
import CriticalAlertModal from './CriticalAlertModal';
import ServiceAlertModal from './ServiceAlertModal';
import RecoveryAlertModal from './RecoveryAlertModal';
import MinimizedAlert from './MinimizedAlert';
import DiskAlertModal from './DiskAlertModal';
import { MonitoredService, DiskInfo, ServiceStatus } from '../types';
import { speak } from '../services/voiceService';

const AUTO_MINIMIZE_SECONDS = 15;

const Layout: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  // Alert States
  const [criticalHost, setCriticalHost] = useState<string | null>(null);
  const [serviceAlert, setServiceAlert] = useState<{ hostname: string, services: MonitoredService[] } | null>(null);
  const [recoveryInfo, setRecoveryInfo] = useState<{ hostname: string, services: MonitoredService[] } | null>(null);
  const [diskAlert, setDiskAlert] = useState<{ hostname: string, disks: DiskInfo[] } | null>(null);
  
  const [isServiceAlertMinimized, setIsServiceAlertMinimized] = useState(false);
  const [minimizeCountdown, setMinimizeCountdown] = useState(AUTO_MINIMIZE_SECONDS);

  // State to track previous alert IDs to detect new ones
  const [prevAlertIds, setPrevAlertIds] = useState<Set<string>>(new Set());

  // Rastreamento do estado anterior dos serviços para detectar recuperação
  // Chave: hostId-serviceName, Valor: status
  const lastServiceState = useRef<Map<string, ServiceStatus>>(new Map());

  useEffect(() => {
    // Permite acesso à página de instalação (/install) mesmo sem estar logado
    if (!isAuthenticated() && !location.pathname.startsWith('/install')) {
      navigate('/login');
    }
  }, [navigate, location]);

  // --- NOVO: Recolher Menu Automaticamente no Dashboard ---
  useEffect(() => {
    if (location.pathname === '/') {
      setIsSidebarCollapsed(true);
    }
  }, [location.pathname]);

  useEffect(() => {
      // Só busca alertas se estiver autenticado ou se o backend estiver acessível
      if (!isAuthenticated()) return;

      const checkAlerts = async () => {
          const alerts = await getAlerts(); // Now fetches DB alerts, but usually recent ones
          const hosts = await getHosts();
          
          // --- LOGICA DE RECUPERAÇÃO E FALHA DE SERVIÇO COM VOZ ---
          hosts.forEach(host => {
              if (!host.services) return;

              const recoveredServices: MonitoredService[] = [];
              const failedServices: MonitoredService[] = [];

              host.services.forEach(service => {
                  const key = `${host.id}-${service.name}`;
                  const prevStatus = lastServiceState.current.get(key);
                  const currentStatus = service.status;

                  // Detecta FALHA (Novo erro)
                  if (currentStatus === 'failed' && prevStatus !== 'failed') {
                      failedServices.push(service);
                  }

                  // Detecta RECUPERAÇÃO (Estava failed, agora active)
                  if (prevStatus === 'failed' && currentStatus === 'active') {
                      recoveredServices.push(service);
                  }

                  // Atualiza o estado
                  lastServiceState.current.set(key, currentStatus);
              });

              // Ação para Recuperação
              if (recoveredServices.length > 0) {
                  setRecoveryInfo({ hostname: host.hostname, services: recoveredServices });
                  // Fecha modal de alerta se tudo foi resolvido
                  if (serviceAlert && serviceAlert.hostname === host.hostname) {
                      const stillFailing = serviceAlert.services.filter(s => 
                          !recoveredServices.find(rs => rs.name === s.name)
                      );
                      if (stillFailing.length === 0) {
                          setServiceAlert(null); // Fecha se todos recuperaram
                      } else {
                          setServiceAlert({ ...serviceAlert, services: stillFailing });
                      }
                  }
                  
                  // VOZ DE RECUPERAÇÃO
                  const names = recoveredServices.map(s => s.name).join(', ');
                  speak(`Serviço restabelecido: ${names}, no servidor ${host.hostname}.`);
                  
                  // Auto-fechar popup de recuperação após 5s
                  setTimeout(() => setRecoveryInfo(null), 8000);
              }

              // Ação para Falha (VOZ)
              if (failedServices.length > 0) {
                   const names = failedServices.map(s => s.name).join(', ');
                   speak(`Atenção. O serviço ${names}, no servidor ${host.hostname}, está inativo.`);
              }
          });
          // --------------------------------------------------------


          // 1. Check for new critical alerts to show modal (Logica existente visual)
          const newCriticalAlerts = alerts.filter(a => 
              a.severity === 'critical' && 
              !a.resolved && 
              !prevAlertIds.has(a.id)
          );

          if (newCriticalAlerts.length > 0) {
              const latest = newCriticalAlerts[0];
              
              if (latest.message.includes('Falha de Serviço')) {
                   const host = hosts.find(h => h.id === latest.hostId);
                   if (host) {
                       const failedServices = host.services?.filter(s => s.status === 'failed') || [];
                       if (failedServices.length > 0) {
                           setServiceAlert({ hostname: host.hostname, services: failedServices });
                           setIsServiceAlertMinimized(false);
                           setMinimizeCountdown(AUTO_MINIMIZE_SECONDS);
                       }
                   }
              } else if (latest.message.includes('Status do Host')) {
                  setCriticalHost(latest.hostname);
              } else if (latest.message.includes('Disco Crítico')) {
                  const host = hosts.find(h => h.id === latest.hostId);
                  if (host) {
                       setDiskAlert({ hostname: host.hostname, disks: host.disks });
                  }
              }

              const newIds = new Set(prevAlertIds);
              newCriticalAlerts.forEach(a => newIds.add(a.id));
              setPrevAlertIds(newIds);
          }
      };

      const interval = setInterval(checkAlerts, 2000);
      return () => clearInterval(interval);
  }, [prevAlertIds, serviceAlert]);

  // Countdown timer for minimized alert
  useEffect(() => {
      let timer: any;
      if (serviceAlert && !isServiceAlertMinimized && minimizeCountdown > 0) {
          timer = setInterval(() => {
              setMinimizeCountdown(prev => prev - 1);
          }, 1000);
      } else if (minimizeCountdown === 0 && !isServiceAlertMinimized) {
          setIsServiceAlertMinimized(true);
      }
      return () => clearInterval(timer);
  }, [serviceAlert, isServiceAlertMinimized, minimizeCountdown]);


  return (
    <div className="flex h-screen bg-slate-950 text-slate-300 overflow-hidden font-sans selection:bg-blue-500/30">
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        toggleSidebar={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
      />

      <main className={`flex-1 overflow-auto transition-all duration-300 p-4 lg:p-6 ${isSidebarCollapsed ? 'ml-20' : 'ml-64'}`}>
        <div className="w-full">
             <Outlet />
        </div>
      </main>

      {/* Modals */}
      <CriticalAlertModal 
        hostname={criticalHost} 
        onClose={() => setCriticalHost(null)} 
      />

      {serviceAlert && !isServiceAlertMinimized && (
        <ServiceAlertModal 
            hostname={serviceAlert.hostname} 
            services={serviceAlert.services}
            countdown={minimizeCountdown}
            onMinimize={() => setIsServiceAlertMinimized(true)}
        />
      )}

      {serviceAlert && isServiceAlertMinimized && (
          <MinimizedAlert 
            hostname={serviceAlert.hostname}
            services={serviceAlert.services}
            onRestore={() => {
                setIsServiceAlertMinimized(false);
                setMinimizeCountdown(AUTO_MINIMIZE_SECONDS);
            }}
          />
      )}

      <RecoveryAlertModal info={recoveryInfo} />
      
      <DiskAlertModal 
        hostInfo={diskAlert} 
        onClose={() => setDiskAlert(null)} 
      />
    </div>
  );
};

export default Layout;
