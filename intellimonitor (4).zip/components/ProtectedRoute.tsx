import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { getCurrentUser, getUserRole } from '../services/authService';

interface Props {
  allowedRoles?: string[]; // Ex: ['admin', 'operador']
}

const ProtectedRoute: React.FC<Props> = ({ allowedRoles }) => {
  const user = getCurrentUser();
  const userRole = getUserRole();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Se houver restrição de roles e o usuário não tiver a role necessária
  if (allowedRoles && !allowedRoles.includes(userRole)) {
    // Redireciona para dashboard (home) se tentar acessar rota proibida
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;