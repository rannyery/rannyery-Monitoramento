// --- ARQUIVO DE CONFIGURAÇÃO GLOBAL (IntelliMonitor) ---
// Este arquivo é carregado antes do React. 
// Você pode usá-lo para distribuir a aplicação com uma URL pré-definida.

window.INTELLI_CONFIG = {
  // Opcional: Defina a URL do backend aqui para forçar a conexão.
  // Exemplo: "http://192.168.1.100:5077"
  // Se deixar como null ou "", o sistema permitirá que o usuário digite na tela de Configurações.
  backendUrl: "" 
};