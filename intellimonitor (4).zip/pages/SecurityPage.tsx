
import React, { useState, useEffect, useMemo } from 'react';
import { Shield, User, Users, Lock, Plus, Trash2, Edit2, CheckCircle2, XCircle, AlertTriangle, Search, Loader2, Ban } from 'lucide-react';
import { getUsers, saveUser, deleteUser, getUserGroups, saveUserGroup } from '../services/mockData';
import { User as UserType, UserGroup } from '../types';

const SecurityPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'users' | 'groups'>('users');
  const [users, setUsers] = useState<UserType[]>([]);
  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [notification, setNotification] = useState<{msg: string, type: 'success' | 'error'} | null>(null);

  // Form States
  const [showUserModal, setShowUserModal] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<UserType> | null>(null);
  const [editingGroup, setEditingGroup] = useState<Partial<UserGroup> | null>(null);
  const [password, setPassword] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
        // Sempre buscamos grupos pois são necessários para o cadastro de usuários
        const gData = await getUserGroups();
        setGroups(gData || []);

        if (activeTab === 'users') {
            const uData = await getUsers();
            setUsers(uData || []);
        }
    } catch (e) {
        showNotify('Erro ao carregar dados. Verifique a conexão com o backend.', 'error');
    } finally {
        setLoading(false);
    }
  };

  const showNotify = (msg: string, type: 'success' | 'error') => {
      setNotification({ msg, type });
      setTimeout(() => setNotification(null), 3000);
  };

  // --- USER ACTIONS ---
  const handleSaveUser = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!editingUser?.username || !editingUser?.group_id) {
          showNotify('Preencha todos os campos obrigatórios.', 'error');
          return;
      }
      
      setIsSaving(true);
      try {
          if (!editingUser.id && !password) {
               showNotify('Senha é obrigatória para novos usuários.', 'error');
               setIsSaving(false);
               return;
          }

          await saveUser({ ...editingUser, password: password || undefined });
          showNotify('Usuário salvo com sucesso!', 'success');
          setShowUserModal(false);
          setPassword('');
          fetchData();
      } catch (e: any) {
          showNotify(e.message, 'error');
      } finally {
          setIsSaving(false);
      }
  };

  const handleDeleteUser = async (id: string) => {
      if (!window.confirm('Tem certeza que deseja excluir este usuário permanentemente?')) return;
      try {
          await deleteUser(id);
          showNotify('Usuário excluído.', 'success');
          fetchData();
      } catch (e: any) {
          showNotify(e.message, 'error');
      }
  };

  const openUserModal = (user?: UserType) => {
      setEditingUser(user ? { ...user } : { username: '', role: 'viewer', group_id: undefined });
      setPassword('');
      setShowUserModal(true);
  };

  // --- GROUP ACTIONS ---
  const handleSaveGroup = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!editingGroup?.name) return;
      setIsSaving(true);
      try {
          await saveUserGroup(editingGroup);
          showNotify('Grupo criado com sucesso!', 'success');
          setShowGroupModal(false);
          fetchData();
      } catch (e: any) {
          showNotify(e.message, 'error');
      } finally {
          setIsSaving(false);
      }
  };
  
  const openGroupModal = () => {
      setEditingGroup({ name: '', description: '' });
      setShowGroupModal(true);
  };

  // --- FILTROS ---
  const filteredUsers = useMemo(() => {
      return users.filter(u => 
          u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (u.group_name || '').toLowerCase().includes(searchTerm.toLowerCase())
      );
  }, [users, searchTerm]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {notification && (
          <div className={`fixed top-20 right-8 z-50 text-white px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 ${notification.type === 'success' ? 'bg-emerald-600' : 'bg-red-600'} animate-in slide-in-from-right-10`}>
              {notification.type === 'success' ? <CheckCircle2 className="w-5 h-5"/> : <AlertTriangle className="w-5 h-5"/>}
              <span className="font-medium">{notification.msg}</span>
          </div>
      )}

      {/* Header Principal */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                <Shield className="w-8 h-8 text-blue-500" /> 
                Segurança
            </h1>
            <p className="text-slate-400 mt-1">Controle de acesso baseado em funções (RBAC).</p>
          </div>
          
          <div className="bg-slate-900/50 border border-slate-800 p-1 rounded-xl flex self-start">
              <button 
                onClick={() => setActiveTab('users')}
                className={`px-6 py-2.5 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${activeTab === 'users' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'}`}
              >
                  <User className="w-4 h-4" /> Usuários
              </button>
              <div className="w-px bg-slate-800 mx-1 my-2"></div>
              <button 
                onClick={() => setActiveTab('groups')}
                className={`px-6 py-2.5 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${activeTab === 'groups' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'}`}
              >
                  <Users className="w-4 h-4" /> Grupos
              </button>
          </div>
      </div>

      {loading && users.length === 0 && groups.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500">
              <Loader2 className="w-10 h-10 animate-spin mb-4 text-blue-500" />
              <p>Carregando dados de segurança...</p>
          </div>
      ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              
              {/* --- CONTEÚDO: TABELA DE USUÁRIOS --- */}
              {activeTab === 'users' && (
                  <>
                    {/* Barra de Ferramentas */}
                    <div className="p-5 border-b border-slate-800 bg-slate-950/30 flex flex-col md:flex-row justify-between items-center gap-4">
                        <div className="relative w-full md:w-96 group">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
                            <input 
                                type="text" 
                                placeholder="Buscar usuário ou grupo..." 
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-sm text-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <button 
                            onClick={() => openUserModal()} 
                            className="w-full md:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg flex items-center justify-center gap-2 transition-all hover:shadow-lg hover:shadow-emerald-900/20 active:scale-95"
                        >
                            <Plus className="w-4 h-4" /> Adicionar Usuário
                        </button>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="text-slate-400 bg-slate-950/20 border-b border-slate-800">
                                <tr>
                                    <th className="px-6 py-4 font-semibold">Usuário</th>
                                    <th className="px-6 py-4 font-semibold">Grupo / Permissão</th>
                                    <th className="px-6 py-4 font-semibold">Data Criação</th>
                                    <th className="px-6 py-4 font-semibold text-right">Ações</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/50">
                                {filteredUsers.length === 0 ? (
                                    <tr>
                                        <td colSpan={4} className="px-6 py-16 text-center text-slate-500">
                                            <div className="flex flex-col items-center gap-3">
                                                <div className="bg-slate-800 p-4 rounded-full"><Search className="w-6 h-6 text-slate-400"/></div>
                                                <p>Nenhum usuário encontrado.</p>
                                            </div>
                                        </td>
                                    </tr>
                                ) : (
                                    filteredUsers.map(user => (
                                        <tr key={user.id} className="hover:bg-slate-800/30 transition-colors group">
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-3">
                                                    <div className="bg-slate-800 p-2 rounded-full text-slate-300 border border-slate-700"><User className="w-4 h-4" /></div>
                                                    <span className="font-medium text-slate-200">{user.username}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wide border ${
                                                    (user.group_name || user.role) === 'admin' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' : 
                                                    (user.group_name || user.role) === 'operador' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 
                                                    'bg-slate-700/30 text-slate-400 border-slate-700'
                                                }`}>
                                                    {(user.group_name || user.role) === 'admin' && <Shield className="w-3 h-3" />}
                                                    {user.group_name || user.role || 'N/A'}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-slate-500 font-mono text-xs">
                                                {user.created_at ? new Date(user.created_at).toLocaleDateString() : '-'}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex justify-end gap-2 opacity-60 group-hover:opacity-100 transition-opacity">
                                                    <button onClick={() => openUserModal(user)} className="p-2 hover:bg-blue-500/20 hover:text-blue-400 rounded-lg transition-colors" title="Editar">
                                                        <Edit2 className="w-4 h-4" />
                                                    </button>
                                                    {user.username !== 'admin' ? (
                                                        <button onClick={() => handleDeleteUser(user.id)} className="p-2 hover:bg-red-500/20 hover:text-red-400 rounded-lg transition-colors" title="Excluir">
                                                            <Trash2 className="w-4 h-4" />
                                                        </button>
                                                    ) : (
                                                        <div className="p-2 text-slate-600 cursor-not-allowed" title="O usuário admin não pode ser excluído">
                                                            <Ban className="w-4 h-4" />
                                                        </div>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                  </>
              )}

              {/* --- CONTEÚDO: GRADE DE GRUPOS --- */}
              {activeTab === 'groups' && (
                  <>
                    <div className="p-5 border-b border-slate-800 bg-slate-950/30 flex justify-between items-center">
                        <div>
                            <h3 className="font-medium text-slate-200">Grupos de Acesso</h3>
                            <p className="text-xs text-slate-500 mt-1">Defina os papéis disponíveis no sistema.</p>
                        </div>
                        <button onClick={openGroupModal} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg flex items-center gap-2 transition-colors hover:shadow-lg hover:shadow-emerald-900/20">
                            <Plus className="w-4 h-4" /> Novo Grupo
                        </button>
                    </div>
                    
                    <div className="p-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {groups.map(group => {
                                const isSystemGroup = ['admin', 'operador', 'visualizador'].includes(group.name);
                                return (
                                    <div key={group.id} className="bg-slate-950 border border-slate-800 rounded-xl p-6 hover:border-blue-500/40 transition-all group relative hover:shadow-xl hover:shadow-blue-900/5">
                                        <div className="flex items-start justify-between mb-4">
                                            <div className={`p-3 rounded-xl border ${isSystemGroup ? 'bg-slate-900 border-slate-800' : 'bg-blue-900/20 border-blue-800/30'}`}>
                                                {group.name === 'admin' ? <Shield className="w-6 h-6 text-purple-500" /> : 
                                                 group.name === 'operador' ? <Edit2 className="w-6 h-6 text-blue-500" /> : 
                                                 <Users className="w-6 h-6 text-slate-400" />}
                                            </div>
                                            {isSystemGroup && (
                                                <span className="text-[10px] bg-slate-800 text-slate-500 px-2 py-1 rounded-md border border-slate-700 font-mono font-bold">SISTEMA</span>
                                            )}
                                        </div>
                                        <h4 className="font-bold text-white capitalize text-lg mb-2">{group.name}</h4>
                                        <p className="text-sm text-slate-400 line-clamp-3 min-h-[3rem]">
                                            {group.description || 'Sem descrição disponível.'}
                                        </p>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                  </>
              )}
          </div>
      )}

      {/* --- MODAL USUÁRIO --- */}
      {showUserModal && editingUser && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
              <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
                  <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex justify-between items-center">
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                          <User className="w-5 h-5 text-blue-500" />
                          {editingUser.id ? 'Editar Usuário' : 'Novo Usuário'}
                      </h3>
                      <button onClick={() => setShowUserModal(false)} className="text-slate-500 hover:text-white"><XCircle className="w-5 h-5"/></button>
                  </div>
                  
                  <form onSubmit={handleSaveUser} className="p-6 space-y-5">
                      <div>
                          <label className="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Nome de Usuário</label>
                          <input 
                            type="text" 
                            required
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                            value={editingUser.username || ''}
                            onChange={e => setEditingUser({...editingUser, username: e.target.value})}
                            placeholder="ex: joao.silva"
                          />
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Grupo de Acesso</label>
                          <div className="relative">
                              <select 
                                required
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all appearance-none"
                                value={editingUser.group_id || ''}
                                onChange={e => setEditingUser({...editingUser, group_id: Number(e.target.value)})}
                              >
                                  <option value="">Selecione um grupo...</option>
                                  {groups.map(g => (
                                      <option key={g.id} value={g.id}>{g.name} - {g.description?.slice(0, 30)}...</option>
                                  ))}
                              </select>
                              <Users className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                          </div>
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wider flex justify-between">
                              Senha 
                              {editingUser.id && <span className="text-[10px] text-blue-400 normal-case font-normal">Opcional na edição</span>}
                          </label>
                          <div className="relative">
                              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                              <input 
                                type="password" 
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                placeholder={editingUser.id ? "Mantenha em branco para não alterar" : "Defina uma senha forte"}
                              />
                          </div>
                      </div>

                      <div className="flex gap-3 mt-8 pt-2">
                          <button type="button" onClick={() => setShowUserModal(false)} className="flex-1 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium transition-colors">Cancelar</button>
                          <button type="submit" disabled={isSaving} className="flex-1 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 flex justify-center items-center gap-2">
                              {isSaving ? <Loader2 className="w-4 h-4 animate-spin"/> : <CheckCircle2 className="w-4 h-4"/>}
                              Salvar
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      {/* --- MODAL GRUPO --- */}
      {showGroupModal && editingGroup && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
              <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
                  <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex justify-between items-center">
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                          <Users className="w-5 h-5 text-emerald-500" />
                          Novo Grupo
                      </h3>
                      <button onClick={() => setShowGroupModal(false)} className="text-slate-500 hover:text-white"><XCircle className="w-5 h-5"/></button>
                  </div>
                  <form onSubmit={handleSaveGroup} className="p-6 space-y-5">
                      <div>
                          <label className="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Nome do Grupo</label>
                          <input 
                            type="text" 
                            required
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                            value={editingGroup.name || ''}
                            onChange={e => setEditingGroup({...editingGroup, name: e.target.value.toLowerCase()})}
                            placeholder="ex: auditoria"
                          />
                          <p className="text-xs text-slate-500 mt-1">Será salvo em minúsculas para uso interno.</p>
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Descrição</label>
                          <textarea 
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all min-h-[100px] resize-none"
                            value={editingGroup.description || ''}
                            onChange={e => setEditingGroup({...editingGroup, description: e.target.value})}
                            placeholder="Descreva as responsabilidades deste grupo..."
                          />
                      </div>

                      <div className="flex gap-3 mt-8 pt-2">
                          <button type="button" onClick={() => setShowGroupModal(false)} className="flex-1 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium transition-colors">Cancelar</button>
                          <button type="submit" disabled={isSaving} className="flex-1 px-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 flex justify-center items-center gap-2">
                              {isSaving ? <Loader2 className="w-4 h-4 animate-spin"/> : <CheckCircle2 className="w-4 h-4"/>}
                              Criar Grupo
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      )}

    </div>
  );
};

export default SecurityPage;
