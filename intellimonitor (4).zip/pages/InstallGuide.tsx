
import React, { useState, useEffect, useRef } from 'react';
import { Copy, Check, Terminal, Server, AlertTriangle, Database, PlugZap, Globe, FileText, Archive, Plus, Trash2, Download, Wand2, ArrowRight, ArrowLeft, Save as SaveIcon, Upload, ToggleLeft, ToggleRight, Cog, Loader2, Play, Settings2, Shield, Lock, Eye, Monitor, Code2, Laptop, ServerCog } from 'lucide-react';
import { getBackendUrl, getHostById } from '../services/mockData';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { canEdit } from '../services/authService';

// --- TIPOS E INTERFACES ---
interface FormField {
  name: string;
  label: string;
  type: 'text' | 'password';
  placeholder?: string;
  span?: 'full';
}

interface ServiceTypeInfo {
  id: number;
  type_key: string;
  display_name: string;
  config_schema: {
    fields: FormField[];
  };
}

interface DynamicServiceConfig {
    id: string;
    name: string;
    typeKey: string;
    enabled: boolean;
    values: Record<string, string>;
}

interface SavedAgentConfig {
  id: string;
  name: string;
  services: DynamicServiceConfig[];
}

// --- CONFIGURAÇÃO DOS ÍCONES ---
const serviceTypeIcons: Record<string, React.FC<any>> = {
    oracle: Database,
    socket: PlugZap,
    webservice: Globe,
    report: FileText,
    registry: Archive,
    process: Cog,
};

// --- CÓDIGO DO BACKEND (Mantido com todas as correções e escapes necessários) ---
const backendServerCode = `const express = require('express');
const cors = require('cors');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { Pool } = require('pg');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 5077;
const JWT_SECRET = 'seu-segredo-super-secreto-para-jwt-aqui'; 

// CONFIGURAÇÃO DO BANCO DE DADOS
const dbConfig = { user: 'postgres', host: 'localhost', database: 'intellisysmonitor', password: 'admin', port: 5432 };
const pool = new Pool(dbConfig);

// Função auxiliar para descobrir o IP local da máquina (Apenas para logs)
const getServerIP = () => {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if ('IPv4' !== iface.family || iface.internal) continue;
            return iface.address;
        }
    }
    return '127.0.0.1';
};

// --- SEGURANÇA: Mascaramento de Dados ---
const SENSITIVE_KEYS = ['oraclePassword', 'password', 'clientSecret', 'secret', 'key'];
const MASK_VALUE = '__PROTECTED__';

const maskSensitiveData = (obj) => {
    if (!obj) return obj;
    if (Array.isArray(obj)) return obj.map(maskSensitiveData);
    if (typeof obj === 'object') {
        const newObj = {};
        for (const key in obj) {
            // Verifica se a chave contém termos sensíveis
            const isSensitive = SENSITIVE_KEYS.some(k => key.toLowerCase().includes(k.toLowerCase()));
            
            // Não mascarar 'typeKey' (tipo de serviço) mesmo que contenha a palavra 'key'
            if (isSensitive && key !== 'typeKey' && obj[key]) {
                 newObj[key] = MASK_VALUE;
            } else {
                 newObj[key] = maskSensitiveData(obj[key]);
            }
        }
        return newObj;
    }
    return obj;
};

// --- INICIALIZAÇÃO AUTOMÁTICA DO BANCO DE DADOS ---
const initDb = async () => {
    const client = await pool.connect();
    try {
        console.log('🔄 Verificando e inicializando estrutura do banco de dados...');

        // 1. Grupos de Usuários (Segurança)
        await client.query(\`
            CREATE TABLE IF NOT EXISTS user_groups (
                id SERIAL PRIMARY KEY,
                name VARCHAR(50) UNIQUE NOT NULL,
                description TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
        \`);
        
        // Insere grupos padrão se não existirem
        await client.query(\`
            INSERT INTO user_groups (name, description) VALUES
            ('admin', 'Acesso total ao sistema e configurações'),
            ('operador', 'Pode gerenciar hosts e alertas, mas não configurações globais'),
            ('visualizador', 'Apenas visualização de dashboards')
            ON CONFLICT (name) DO NOTHING;
        \`);

        // 2. Tabelas Básicas
        await client.query(\`
            CREATE TABLE IF NOT EXISTS users (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                username VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL DEFAULT 'admin123',
                role VARCHAR(50) NOT NULL DEFAULT 'viewer',
                group_id INT REFERENCES user_groups(id) ON DELETE SET NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
            
            CREATE TABLE IF NOT EXISTS hosts (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                hostname VARCHAR(255) UNIQUE NOT NULL,
                ip_address VARCHAR(45),
                os VARCHAR(50),
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );

            CREATE TABLE IF NOT EXISTS host_status_and_config (
                host_id UUID PRIMARY KEY REFERENCES hosts(id) ON DELETE CASCADE,
                status VARCHAR(50) DEFAULT 'offline',
                uptime_seconds BIGINT,
                last_seen TIMESTAMPTZ,
                monitoring_enabled BOOLEAN DEFAULT true
            );
            
            CREATE TABLE IF NOT EXISTS alerts (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                host_id UUID REFERENCES hosts(id) ON DELETE CASCADE,
                severity VARCHAR(20),
                message TEXT,
                timestamp TIMESTAMPTZ DEFAULT NOW(),
                resolved BOOLEAN DEFAULT false,
                resolved_at TIMESTAMPTZ,
                alert_key VARCHAR(255)
            );
            CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp);
            CREATE INDEX IF NOT EXISTS idx_alerts_host ON alerts(host_id);
        \`);
        
        // --- MIGRAÇÃO DE SCHEMA (IMPORTANTE PARA ATUALIZAÇÕES) ---
        try {
            await client.query(\`
                DO $$ 
                BEGIN 
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='group_id') THEN 
                        ALTER TABLE users ADD COLUMN group_id INT REFERENCES user_groups(id) ON DELETE SET NULL; 
                    END IF;
                END $$;
            \`);
        } catch (e) { console.log('Info: Migração users.group_id:', e.message); }

        // --- CORREÇÃO DE DADOS ---
        const adminGroupRes = await client.query("SELECT id FROM user_groups WHERE name = 'admin'");
        if (adminGroupRes.rows.length > 0) {
            const adminGroupId = adminGroupRes.rows[0].id;
            await client.query("UPDATE users SET group_id = $1 WHERE username = 'admin' AND group_id IS NULL", [adminGroupId]);
        }

        const userCheck = await client.query("SELECT * FROM users WHERE username = 'admin'");
        if (userCheck.rows.length === 0) {
            const adminGroupId = adminGroupRes.rows[0]?.id || null;
            await client.query(
                "INSERT INTO users (username, password, role, group_id) VALUES ('admin', 'admin123', 'admin', $1)",
                [adminGroupId]
            );
        }

        try {
            await client.query("ALTER TABLE host_status_and_config ALTER COLUMN status SET DEFAULT 'offline'");
        } catch (e) {}

        // 3. Tipos de Serviço (UPSERT para garantir consistência)
        await client.query(\`
            CREATE TABLE IF NOT EXISTS service_types (
                id SERIAL PRIMARY KEY,
                type_key VARCHAR(50) UNIQUE NOT NULL, 
                display_name VARCHAR(255) NOT NULL,
                config_schema JSONB NOT NULL
            )
        \`);

        const defaultTypes = [
            { key: 'oracle', name: 'Banco de Dados Oracle', schema: { "fields": [{ "name": "oracleUser", "label": "Usuário Oracle", "type": "text" }, { "name": "oraclePassword", "label": "Senha Oracle", "type": "password" }, { "name": "tnsName", "label": "String de Conexão (TNS ou IP:Porta/Service)", "type": "text", "span": "full" }] } },
            { key: 'socket', name: 'Conexão Socket', schema: { "fields": [{ "name": "ip", "label": "Endereço IP", "type": "text" }, { "name": "port", "label": "Porta", "type": "text" }] } },
            { key: 'webservice', name: 'WebService (URL)', schema: { "fields": [{ "name": "url", "label": "URL Completa", "type": "text", "span": "full" }, { "name": "clientId", "label": "Client ID", "type": "text" }, { "name": "clientSecret", "label": "Client Secret", "type": "password" }] } },
            { key: 'report', name: 'Serviço de Relatório', schema: { "fields": [{ "name": "ip", "label": "Endereço IP", "type": "text" }, { "name": "port", "label": "Porta", "type": "text" }] } },
            { key: 'registry', name: 'Serviço de Registro', schema: { "fields": [{ "name": "ip", "label": "Endereço IP", "type": "text" }, { "name": "port", "label": "Porta", "type": "text" }] } },
            { key: 'process', name: 'Processo (Executável)', schema: { "fields": [{ "name": "processName", "label": "Nome do Executável", "type": "text", "span": "full" }] } }
        ];

        for (const t of defaultTypes) {
            await client.query(\`
                INSERT INTO service_types (type_key, display_name, config_schema) 
                VALUES ($1, $2, $3)
                ON CONFLICT (type_key) DO UPDATE SET 
                    display_name = EXCLUDED.display_name,
                    config_schema = EXCLUDED.config_schema
            \`, [t.key, t.name, JSON.stringify(t.schema)]);
        }

        // 4. Configurações e Métricas
        await client.query(\`
            CREATE TABLE IF NOT EXISTS host_service_configs (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                host_id UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
                service_type_id INT NOT NULL REFERENCES service_types(id) ON DELETE RESTRICT,
                service_name VARCHAR(255) NOT NULL,
                is_enabled BOOLEAN NOT NULL DEFAULT true,
                config_values JSONB NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
            CREATE INDEX IF NOT EXISTS idx_hsc_host_id ON host_service_configs(host_id);

             CREATE TABLE IF NOT EXISTS service_status_history (
                host_id UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
                service_name VARCHAR(255) NOT NULL,
                status VARCHAR(50),
                details TEXT,
                last_checked TIMESTAMPTZ NOT NULL,
                PRIMARY KEY (host_id, service_name)
            );
            
            CREATE TABLE IF NOT EXISTS metrics (
                timestamp TIMESTAMPTZ NOT NULL,
                host_id UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
                cpu_usage FLOAT,
                memory_usage FLOAT,
                disk_used_gb FLOAT,
                disk_total_gb FLOAT,
                PRIMARY KEY (timestamp, host_id)
            );

            CREATE TABLE IF NOT EXISTS system_settings (
                setting_key VARCHAR(50) PRIMARY KEY,
                setting_value VARCHAR(255) NOT NULL,
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        \`);
        
        await client.query(\`
            INSERT INTO system_settings (setting_key, setting_value, updated_at)
            VALUES ('server_port', $1, NOW())
            ON CONFLICT (setting_key) DO NOTHING
        \`, [String(PORT)]);

        console.log("✅ Banco de dados inicializado e atualizado.");

    } catch (e) {
        console.error("❌ ERRO AO INICIALIZAR DB:", e);
    } finally {
        client.release();
    }
};

initDb();

let sslOptions = {};
try {
    sslOptions = { key: fs.readFileSync(path.join(__dirname, 'key.pem')), cert: fs.readFileSync(path.join(__dirname, 'cert.pem')) };
} catch (error) {
    console.error("❌ ERRO: key.pem ou cert.pem não encontrados.");
    process.exit(1);
}

app.use(cors({ origin: '*', methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'] }));
app.use(express.json());
app.use('/api', (req, res, next) => {
    // Middleware para logs de API
    next();
});

app.get('/', (req, res) => res.send('✅ IntelliMonitor Backend está ONLINE!'));

app.get('/api/system-settings', async (req, res) => {
    try {
        const result = await pool.query('SELECT setting_key, setting_value FROM system_settings');
        const settings = result.rows.reduce((acc, row) => { acc[row.setting_key] = row.setting_value; return acc; }, {});
        res.json(settings);
    } catch (e) { res.status(500).json({ error: 'Erro ao buscar settings' }); }
});

app.post('/api/system-settings', async (req, res) => {
    const { ip, port } = req.body;
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        if (ip) {
             await client.query(\`INSERT INTO system_settings (setting_key, setting_value, updated_at) VALUES ('server_ip', $1, NOW())
             ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()\`, [ip]);
        }
        if (port) {
             await client.query(\`INSERT INTO system_settings (setting_key, setting_value, updated_at) VALUES ('server_port', $1, NOW())
             ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()\`, [port]);
        }
        await client.query('COMMIT');
        res.json({ status: 'ok' });
    } catch (e) {
        await client.query('ROLLBACK');
        res.status(500).json({ error: 'Erro ao salvar.' });
    } finally { client.release(); }
});

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const result = await pool.query(\`
            SELECT u.*, g.name as group_name 
            FROM users u 
            LEFT JOIN user_groups g ON u.group_id = g.id 
            WHERE u.username = $1
        \`, [username]);
        
        const user = result.rows[0];
        if (!user || user.password !== password) return res.status(401).json({ error: 'Credenciais inválidas' });
        
        const role = user.group_name || user.role || 'viewer';
        
        const token = jwt.sign({ id: user.id, username: user.username, role: role }, JWT_SECRET, { expiresIn: '8h' });
        res.json({ id: user.id, username: user.username, role: role, token: token, group_id: user.group_id });
    } catch (e) { 
        console.error("Erro no login:", e);
        res.status(500).json({ error: 'Erro interno: ' + e.message }); 
    }
});

// --- SEGURANÇA (USUÁRIOS E GRUPOS) ---

app.get('/api/users', async (req, res) => {
    try {
        const result = await pool.query(\`
            SELECT u.id, u.username, u.role, u.group_id, u.created_at, g.name as group_name 
            FROM users u 
            LEFT JOIN user_groups g ON u.group_id = g.id 
            ORDER BY u.username
        \`);
        res.json(result.rows);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/users', async (req, res) => {
    const { username, password, group_id } = req.body;
    try {
        let roleName = 'viewer';
        if (group_id) {
            const gRes = await pool.query("SELECT name FROM user_groups WHERE id = $1", [group_id]);
            if (gRes.rows.length > 0) roleName = gRes.rows[0].name;
        }

        await pool.query(
            "INSERT INTO users (username, password, role, group_id) VALUES ($1, $2, $3, $4)",
            [username, password, roleName, group_id]
        );
        res.json({ status: 'ok' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/users/:id', async (req, res) => {
    const { id } = req.params;
    const { username, password, group_id } = req.body;
    try {
        let roleName = 'viewer';
        if (group_id) {
            const gRes = await pool.query("SELECT name FROM user_groups WHERE id = $1", [group_id]);
            if (gRes.rows.length > 0) roleName = gRes.rows[0].name;
        }

        if (password) {
            await pool.query(
                "UPDATE users SET username = $1, password = $2, role = $3, group_id = $4 WHERE id = $5",
                [username, password, roleName, group_id, id]
            );
        } else {
            await pool.query(
                "UPDATE users SET username = $1, role = $2, group_id = $3 WHERE id = $4",
                [username, roleName, group_id, id]
            );
        }
        res.json({ status: 'ok' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/users/:id', async (req, res) => {
    try {
        // Proteção para não excluir o admin principal
        const uRes = await pool.query("SELECT username FROM users WHERE id = $1", [req.params.id]);
        if (uRes.rows.length > 0 && uRes.rows[0].username === 'admin') {
            return res.status(400).json({ error: 'Não é permitido excluir o usuário admin padrão.' });
        }
        await pool.query("DELETE FROM users WHERE id = $1", [req.params.id]);
        res.json({ status: 'ok' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/groups', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM user_groups ORDER BY id');
        res.json(result.rows);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/groups', async (req, res) => {
    const { name, description } = req.body;
    try {
        await pool.query(
            "INSERT INTO user_groups (name, description) VALUES ($1, $2)",
            [name, description]
        );
        res.json({ status: 'ok' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/service-types', async (req, res) => {
    try {
        const result = await pool.query('SELECT id, type_key, display_name, config_schema FROM service_types ORDER BY id');
        res.json(result.rows);
    } catch (e) { res.status(500).json({ error: 'Erro ao buscar tipos.' }); }
});

app.post('/api/alerts/report', async (req, res) => {
    const { host_id, alert_key, severity, message, active } = req.body;
    const client = await pool.connect();
    try {
        if (active) {
            const check = await client.query(
                "SELECT id FROM alerts WHERE host_id = $1 AND alert_key = $2 AND resolved = false",
                [host_id, alert_key]
            );
            if (check.rows.length === 0) {
                await client.query(
                    "INSERT INTO alerts (host_id, severity, message, alert_key, timestamp, resolved) VALUES ($1, $2, $3, $4, NOW(), false)",
                    [host_id, severity, message, alert_key]
                );
            }
        } else {
            await client.query(
                "UPDATE alerts SET resolved = true, resolved_at = NOW() WHERE host_id = $1 AND alert_key = $2 AND resolved = false",
                [host_id, alert_key]
            );
        }
        res.json({status: 'ok'});
    } catch(e) {
        res.status(500).json({error: e.message});
    } finally { client.release(); }
});

app.get('/api/alerts', async (req, res) => {
    const { start_date, end_date, host_id } = req.query;
    let query = \`
        SELECT a.*, h.hostname 
        FROM alerts a 
        LEFT JOIN hosts h ON a.host_id = h.id 
        WHERE 1=1
    \`;
    const params = [];
    let pIdx = 1;
    
    if (start_date) {
        query += \` AND a.timestamp >= $\${pIdx++}\`;
        params.push(start_date);
    }
    if (end_date) {
        query += \` AND a.timestamp <= $\${pIdx++}::date + interval '1 day'\`;
        params.push(end_date);
    }
    if (host_id && host_id !== 'all') {
        query += \` AND a.host_id = $\${pIdx++}\`;
        params.push(host_id);
    }
    
    query += " ORDER BY a.timestamp DESC LIMIT 1000";
    
    const client = await pool.connect();
    try {
        const result = await client.query(query, params);
        res.json(result.rows);
    } catch(e) {
        res.status(500).json({error: e.message});
    } finally { client.release(); }
});

app.post('/api/metrics', async (req, res) => {
    const { hostname, os, metrics, ip, uptimeSeconds, services } = req.body;
    if (!hostname) return res.status(400).json({ error: 'Hostname obrigatório' });

    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const hostRes = await client.query(
            \`INSERT INTO hosts (hostname, ip_address, os) VALUES ($1, $2, $3)
             ON CONFLICT (hostname) DO UPDATE SET ip_address = EXCLUDED.ip_address, os = EXCLUDED.os, updated_at = NOW()
             RETURNING id\`, [hostname, ip || '0.0.0.0', os || 'unknown']
        );
        const hostId = hostRes.rows[0].id;

        await client.query(
            \`INSERT INTO host_status_and_config (host_id, uptime_seconds, last_seen, status) VALUES ($1, $2, NOW(), 'online')
             ON CONFLICT (host_id) DO UPDATE SET uptime_seconds = EXCLUDED.uptime_seconds, last_seen = NOW(), status = 'online'\`, [hostId, uptimeSeconds]
        );
        
        if (metrics) {
            await client.query(
                \`INSERT INTO metrics (timestamp, host_id, cpu_usage, memory_usage, disk_used_gb, disk_total_gb)
                 VALUES (NOW(), $1, $2, $3, $4, $5)\`,
                [hostId, metrics.cpu, metrics.memory, metrics.disk_used_gb, metrics.disk_total_gb]
            );
        }

        if (Array.isArray(services)) {
             for (const service of services) {
                await client.query(
                   \`INSERT INTO service_status_history (host_id, service_name, status, details, last_checked)
                    VALUES ($1, $2, $3, $4, NOW())
                    ON CONFLICT (host_id, service_name) DO UPDATE SET
                       status = EXCLUDED.status, details = EXCLUDED.details, last_checked = NOW()\`,
                    [hostId, service.name, service.status, service.details]
                );
            }
        }
        await client.query('COMMIT');
        res.json({ status: 'ok' });
    } catch (e) {
        await client.query('ROLLBACK');
        res.status(500).json({ error: 'Erro ao salvar métricas' });
    } finally { client.release(); }
});

app.post('/api/config', async (req, res) => {
    const { hostname, services, monitoringEnabled } = req.body;
    if (!hostname) return res.status(400).json({ error: 'Hostname é obrigatório' });
    
    console.log(\`📝 [CONFIG] Recebendo configuração para: \${hostname}\`);

    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const hostRes = await client.query(
            \`INSERT INTO hosts (hostname, ip_address, os) VALUES ($1, '0.0.0.0', 'unknown') 
             ON CONFLICT (hostname) DO UPDATE SET updated_at = NOW() RETURNING id\`, [hostname]
        );
        const hostId = hostRes.rows[0].id;

        const oldConfigsRes = await client.query(
            'SELECT service_name, config_values FROM host_service_configs WHERE host_id = $1', 
            [hostId]
        );
        const oldConfigsMap = new Map();
        oldConfigsRes.rows.forEach(r => oldConfigsMap.set(r.service_name, r.config_values));

        await client.query('DELETE FROM host_service_configs WHERE host_id = $1', [hostId]);

        if (Array.isArray(services)) {
            const serviceTypesRes = await client.query('SELECT id, type_key FROM service_types');
            const typeMap = new Map(serviceTypesRes.rows.map(r => [r.type_key, r.id]));

            for (const service of services) {
                const serviceTypeId = typeMap.get(service.typeKey);
                if (!serviceTypeId) {
                    console.warn(\`⚠️ Tipo de serviço não encontrado: \${service.typeKey}\`);
                    continue;
                }
                
                let configValues = service.values || {};
                
                // LÓGICA DE MERGE SEGURO: Recupera a senha antiga se vier mascarada
                if (oldConfigsMap.has(service.name)) {
                    const oldValues = oldConfigsMap.get(service.name);
                    const newValuesMerged = { ...configValues };
                    for (const key in newValuesMerged) {
                        if (newValuesMerged[key] === MASK_VALUE && oldValues[key]) {
                            newValuesMerged[key] = oldValues[key];
                        }
                    }
                    configValues = newValuesMerged;
                }

                const isEnabled = (service.enabled === undefined || service.enabled === null) ? true : Boolean(service.enabled);

                await client.query(
                    \`INSERT INTO host_service_configs (host_id, service_type_id, service_name, is_enabled, config_values)
                     VALUES ($1, $2, $3, $4, $5)\`,
                    [hostId, serviceTypeId, service.name, isEnabled, JSON.stringify(configValues)]
                );
            }
        }
        
        const monEnabled = (monitoringEnabled === undefined) ? true : Boolean(monitoringEnabled);
        await client.query(
            \`INSERT INTO host_status_and_config (host_id, monitoring_enabled, status) VALUES ($1, $2, 'offline')
             ON CONFLICT (host_id) DO UPDATE SET monitoring_enabled = EXCLUDED.monitoring_enabled\`,
            [hostId, monEnabled]
        );
        
        await client.query('COMMIT');
        console.log(\`✅ [CONFIG] Salvo com sucesso para \${hostname}\`);
        res.json({ status: 'ok' });
    } catch (e) {
        await client.query('ROLLBACK');
        console.error(\`❌ [CONFIG] Erro Fatal: \${e.message}\`);
        res.status(500).json({ error: e.message });
    } finally {
        client.release();
    }
});

app.get('/api/hosts', async (req, res) => {
    const client = await pool.connect();
    try {
        const hostsResult = await client.query(\`
            SELECT
                h.id, h.hostname, h.ip_address as ip, h.os,
                h_cfg.status,
                h_cfg.uptime_seconds, h_cfg.last_seen, h_cfg.monitoring_enabled,
                (SELECT json_agg(json_build_object('id', s_cfg.id, 'name', s_cfg.service_name, 'typeKey', st.type_key, 'enabled', s_cfg.is_enabled, 'values', s_cfg.config_values))
                 FROM host_service_configs s_cfg JOIN service_types st ON s_cfg.service_type_id = st.id WHERE s_cfg.host_id = h.id) as services_config
            FROM hosts h LEFT JOIN host_status_and_config h_cfg ON h.id = h_cfg.host_id
        \`);
        
        if (hostsResult.rows.length === 0) return res.json({});
        const hostIds = hostsResult.rows.map(r => r.id);
        
        const metricsResult = await client.query(\`
            WITH ranked_metrics AS (SELECT m.*, ROW_NUMBER() OVER(PARTITION BY host_id ORDER BY timestamp DESC) as rn FROM metrics m WHERE m.host_id = ANY($1::uuid[]))
            SELECT * FROM ranked_metrics WHERE rn <= 40 ORDER BY host_id, timestamp ASC\`, [hostIds]);
        
        const servicesResult = await client.query(\`
            SELECT h.host_id, h.service_name, h.status, h.details 
            FROM service_status_history h
            JOIN host_service_configs c ON h.host_id = c.host_id AND h.service_name = c.service_name
            WHERE h.host_id = ANY($1::uuid[]) AND c.is_enabled = true
        \`, [hostIds]);

        const metricsByHost = metricsResult.rows.reduce((acc, row) => { (acc[row.host_id] = acc[row.host_id] || []).push(row); return acc; }, {});
        const servicesByHost = servicesResult.rows.reduce((acc, row) => { (acc[row.host_id] = acc[row.host_id] || []).push(row); return acc; }, {});

        const responseData = {};
        for (const host of hostsResult.rows) {
            const hostMetrics = metricsByHost[host.id] || [];
            const latestMetric = hostMetrics[hostMetrics.length - 1] || {};
            
            let finalStatus = host.status || 'offline';
            const lastSeenTime = new Date(host.last_seen).getTime() || 0;
            if (Date.now() - lastSeenTime > 180000) finalStatus = 'offline';

            const safeAgentConfig = {
                services: maskSensitiveData(host.services_config || []),
                monitoringEnabled: host.monitoring_enabled
            };

            responseData[host.hostname] = {
                id: host.id, hostname: host.hostname, ip: host.ip, os: host.os,
                status: finalStatus,
                uptimeSeconds: host.uptime_seconds || 0,
                lastSeen: lastSeenTime,
                agentConfig: safeAgentConfig,
                latestMetrics: { cpu: latestMetric.cpu_usage, memory: latestMetric.memory_usage, disk_total_gb: latestMetric.disk_total_gb, disk_used_gb: latestMetric.disk_used_gb },
                metrics: {
                    cpu: hostMetrics.map(m => ({ timestamp: new Date(m.timestamp).getTime(), value: m.cpu_usage })),
                    memory: hostMetrics.map(m => ({ timestamp: new Date(m.timestamp).getTime(), value: m.memory_usage })),
                    networkIn: [], networkOut: [],
                },
                disks: latestMetric.disk_total_gb ? [{ mount: host.os === 'windows' ? 'C:\\\\' : '/', total: latestMetric.disk_total_gb, used: latestMetric.disk_used_gb }] : [],
                services: (servicesByHost[host.id] || []).map(s => ({ name: s.service_name, status: s.status, details: s.details, type: 'service' })),
            };
        }
        res.json(responseData);
    } catch (e) {
        res.status(500).json({ error: 'Erro ao buscar dados.' });
    } finally {
        client.release();
    }
});

https.createServer(sslOptions, app).listen(PORT, '0.0.0.0', async () => {
    let displayIp = getServerIP();
    let isDefined = false;
    try {
        const res = await pool.query("SELECT setting_value FROM system_settings WHERE setting_key = 'server_ip'");
        if (res.rows.length > 0) {
             displayIp = res.rows[0].setting_value;
             isDefined = true;
        }
    } catch(e) {}
    console.log(\`\\n🚀 Backend SEGURO rodando!\`);
    console.log(\`👉 Local (LAN):      https://\${getServerIP()}:\${PORT}\`);
    console.log(\`👉 Oficial (Externo): https://\${displayIp}:\${PORT} \${isDefined ? '(Do Banco)' : '(Automático/Temp)'}\`);
});
`;

const InstallGuide: React.FC = () => {
    const { hostId } = useParams();
    const navigate = useNavigate();
    const isEditMode = !!hostId;
    const isAllowedToEdit = canEdit();
    
    // Navegação interna por Abas
    const [activeTab, setActiveTab] = useState<'infra' | 'config' | 'deploy'>(isEditMode ? 'config' : 'infra');

    // Estados
    const [services, setServices] = useState<DynamicServiceConfig[]>([]);
    const [serviceTypes, setServiceTypes] = useState<ServiceTypeInfo[]>([]);
    const [selectedServiceTypeKey, setSelectedServiceTypeKey] = useState<string>('');
    const [isLoadingServiceTypes, setIsLoadingServiceTypes] = useState(true);
    const [generatedScript, setGeneratedScript] = useState('');
    const [notification, setNotification] = useState<{ message: string, type: 'success' | 'error' | 'warning' } | null>(null);
    const [originalHostname, setOriginalHostname] = useState<string | null>(null);
    const [isHostMonitoringEnabled, setIsHostMonitoringEnabled] = useState(true);
    const [isLoadingHost, setIsLoadingHost] = useState(isEditMode);
    
    // Deploy settings
    const [installOs, setInstallOs] = useState<'linux' | 'windows' | 'windows-service'>('linux');
    const [winServicePythonPath, setWinServicePythonPath] = useState("C:\\Users\\Intellisys\\AppData\\Local\\Programs\\Python\\Python312\\python.exe");
    const [winServiceAgentDir, setWinServiceAgentDir] = useState("C:\\CRM\\Monitor");

    const showNotification = (message: string, type: 'success' | 'error' | 'warning' = 'success') => {
        setNotification({ message, type });
        setTimeout(() => setNotification(null), 3500);
    };

    useEffect(() => {
        const fetchServiceTypes = async () => {
            const url = getBackendUrl();
            if (!url) { setIsLoadingServiceTypes(false); return; }
            try {
                const response = await fetch(`${url}/api/service-types`);
                if (!response.ok) throw new Error('Falha ao buscar tipos de serviço');
                const data = await response.json();
                const typesWithIcons: ServiceTypeInfo[] = data.map((t: any) => ({
                    ...t,
                    icon: serviceTypeIcons[t.type_key] || Cog
                }));
                setServiceTypes(typesWithIcons);
                if (typesWithIcons.length > 0) setSelectedServiceTypeKey(typesWithIcons[0].type_key);
            } catch (error) {
                console.error(error);
                showNotification('Erro ao carregar tipos de serviço.', 'error');
            } finally {
                setIsLoadingServiceTypes(false);
            }
        };
        fetchServiceTypes();
    }, []);

    useEffect(() => {
        if (isEditMode && hostId && serviceTypes.length > 0) {
            const loadHostData = async () => {
                setIsLoadingHost(true);
                const hostData = await getHostById(hostId);
                if (!hostData) {
                    showNotification(`Host ${hostId} não encontrado.`, 'error');
                    navigate('/install');
                    return;
                }
                setOriginalHostname(hostData.hostname);
                if (hostData.agentConfig) {
                    const loadedServices: DynamicServiceConfig[] = hostData.agentConfig.services.map((s: any) => ({
                        id: s.id || `s-${Math.random().toString(36).substr(2, 9)}`,
                        name: s.name,
                        typeKey: s.typeKey,
                        enabled: s.enabled,
                        values: s.values || {}
                    }));
                    setServices(loadedServices);
                    setIsHostMonitoringEnabled(hostData.agentConfig.monitoringEnabled);
                    showNotification("Configuração carregada.", 'success');
                } else {
                    setIsHostMonitoringEnabled(hostData.monitoringEnabled !== false);
                }
                setIsLoadingHost(false);
            };
            loadHostData();
        }
    }, [hostId, isEditMode, navigate, serviceTypes]);

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        showNotification("Copiado para a área de transferência!", "success");
    };

    const handleAddService = () => {
        if (!isAllowedToEdit) return;
        const serviceType = serviceTypes.find(st => st.type_key === selectedServiceTypeKey);
        if (!serviceType) return;
        const newService: DynamicServiceConfig = { 
            id: `s-${Date.now()}`, 
            name: `${serviceType.display_name} ${services.filter(s => s.typeKey === selectedServiceTypeKey).length + 1}`,
            enabled: true,
            typeKey: selectedServiceTypeKey,
            values: serviceType.config_schema.fields.reduce((acc, field) => ({ ...acc, [field.name]: '' }), {})
        };
        setServices([...services, newService]);
    };
    
    const handleUpdateService = (id: string, field: string, value: string | boolean) => {
        if (!isAllowedToEdit) return;
        setServices(services.map(s => {
            if (s.id !== id) return s;
            if (field === 'name' || field === 'enabled') return { ...s, [field]: value };
            return { ...s, values: { ...s.values, [field]: String(value) } };
        }));
    };
    
    const handleRemoveService = (id: string) => {
        if (!isAllowedToEdit) return;
        if (window.confirm("Remover este serviço?")) setServices(services.filter(s => s.id !== id));
    };

    const saveToBackend = async (config: any) => {
         const backendUrl = getBackendUrl();
        if (!backendUrl) throw new Error("URL do Backend não configurada.");
        const response = await fetch(`${backendUrl}/api/config`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });
        if (!response.ok) {
             const errorData = await response.json().catch(() => ({ error: `Erro HTTP: ${response.status}` }));
             throw new Error(errorData.error || `Erro HTTP: ${response.status}`);
        }
    }

    const handleSaveConfigOnly = async () => {
         if (!isAllowedToEdit) return;
         const hostnameToSave = originalHostname || `novo-host-${Date.now()}`;
         try {
            await saveToBackend({ hostname: hostnameToSave, services, monitoringEnabled: isHostMonitoringEnabled });
            showNotification("Configuração salva com sucesso (Merge Seguro)!", 'success');
        } catch (e: any) {
             showNotification(`Erro ao salvar: ${e.message}`, 'error');
        }
    }

    const handleGenerateScript = async () => {
        if (!isAllowedToEdit) return;
        const hasMaskedCredentials = services.some(s => Object.values(s.values).some(v => v === '__PROTECTED__') && s.enabled);
        if (hasMaskedCredentials) {
            alert("⚠️ Segurança: Algumas senhas estão ocultas (__PROTECTED__). Para gerar um script funcional, por favor redigite as senhas nos campos de serviço.");
            return;
        }
        
        const hostnameToSave = originalHostname || `novo-host-${Date.now()}`;
        const currentBackendUrl = getBackendUrl();

        try {
            await saveToBackend({ hostname: hostnameToSave, services, monitoringEnabled: isHostMonitoringEnabled });
            if (isEditMode) showNotification("Salvo! Gerando script...", 'success');
        } catch (e: any) {
             showNotification(`Erro ao salvar: ${e.message}`, 'error');
             return;
        }
        
        const activeServices = services.filter(s => s.enabled);
        const sanitizeForPython = (str: string) => str.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

        const serviceCalls = activeServices.map(s => {
            const typeInfo = serviceTypes.find(st => st.type_key === s.typeKey);
            if (!typeInfo) return `# Erro: Tipo desconhecido ${s.typeKey}`;
            const args = [`"${sanitizeForPython(s.name)}"`];
            typeInfo.config_schema.fields.forEach(field => args.push(`"${sanitizeForPython(s.values[field.name] || '')}"`));
            const funcName = { 'oracle': 'check_oracle_status', 'socket': 'check_socket_status', 'report': 'check_socket_status', 'registry': 'check_socket_status', 'webservice': 'check_webservice_status', 'process': 'check_process_status' }[s.typeKey] || 'check_generic_status';
            return `    services.append(${funcName}(${args.join(', ')}))`;
        }).join('\n');

        const script = `# -*- coding: utf-8 -*-
import sys
import time
import json
import socket
import platform
import logging

try:
    import requests
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except ImportError:
    print("ERRO: requests necessária. pip install requests")
    sys.exit(1)

try: import psutil
except ImportError:
    print("ERRO: psutil necessária. pip install psutil")
    sys.exit(1)

BACKEND_URL = "${currentBackendUrl}"
HOSTNAME = "${sanitizeForPython(hostnameToSave)}"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
psutil.cpu_percent(interval=None)

def check_socket_status(name, ip, port):
    try:
        start_time = time.time()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex((ip, int(port)))
        sock.close()
        latency = (time.time() - start_time) * 1000
        return {"name": name, "status": "active" if result == 0 else "failed", "details": f"Conectado em {latency:.1f}ms" if result == 0 else f"Porta fechada ({result})"}
    except Exception as e: return {"name": name, "status": "failed", "details": str(e)}

def check_webservice_status(name, url, client_id=None, client_secret=None):
    try:
        start_time = time.time()
        response = requests.get(url, timeout=10, verify=False)
        latency = (time.time() - start_time) * 1000
        return {"name": name, "status": "active" if 200 <= response.status_code < 400 else "failed", "details": f"HTTP {response.status_code} - {latency:.1f}ms"}
    except Exception as e: return {"name": name, "status": "failed", "details": f"Falha: {str(e)}"}

def check_oracle_status(name, user, password, tns):
    db_lib = None
    try:
        import oracledb
        db_lib = oracledb
        try: oracledb.init_oracle_client(lib_dir=None) 
        except: pass 
    except ImportError:
        try: import cx_Oracle; db_lib = cx_Oracle
        except: return {"name": name, "status": "warning", "details": "Instale: pip install oracledb"}
    try:
        connection = db_lib.connect(user=user, password=password, dsn=tns)
        connection.close()
        return {"name": name, "status": "active", "details": "Conexão Oracle OK"}
    except Exception as e: return {"name": name, "status": "failed", "details": f"Erro Oracle: {str(e)}"}

def check_process_status(name, process_name):
    try:
        found = False
        for proc in psutil.process_iter(['name', 'cmdline']):
            try:
                if process_name.lower() in proc.info['name'].lower(): found = True; break
                if proc.info['cmdline'] and any(process_name.lower() in arg.lower() for arg in proc.info['cmdline']): found = True; break
            except: pass
        return {"name": name, "status": "active" if found else "failed", "details": "Executando" if found else "Não encontrado"}
    except Exception as e: return {"name": name, "status": "failed", "details": str(e)}

def get_system_metrics():
    cpu = psutil.cpu_percent(interval=None)
    memory = psutil.virtual_memory().percent
    disk_total, disk_used = 0, 0
    try:
        disk = psutil.disk_usage('C:\\\\' if platform.system() == 'Windows' else '/')
        disk_total = round(disk.total / (1024**3), 2)
        disk_used = round(disk.used / (1024**3), 2)
    except: pass
    services = []
${serviceCalls}
    net = psutil.net_io_counters()
    return {
        "hostname": HOSTNAME, "ip": socket.gethostbyname(socket.gethostname()), "os": platform.system().lower(),
        "uptimeSeconds": int(time.time() - psutil.boot_time()), "services": services,
        "metrics": {"cpu": cpu, "memory": memory, "disk_total_gb": disk_total, "disk_used_gb": disk_used, "net_sent_mb": round(net.bytes_sent/(1024*1024),2), "net_recv_mb": round(net.bytes_recv/(1024*1024),2)}
    }

def main():
    print(f"Agente iniciado: {HOSTNAME} -> {BACKEND_URL}")
    while True:
        try:
            data = get_system_metrics()
            logging.info(f"Enviando... CPU: {data['metrics']['cpu']}%")
            requests.post(f"{BACKEND_URL}/api/metrics", json=data, verify=False, timeout=10)
        except Exception as e: logging.error(f"Erro: {e}")
        time.sleep(5)

if __name__ == "__main__":
    main()
`;
        setGeneratedScript(script);
        setActiveTab('deploy');
    };

    const downloadAgentScript = () => {
        const blob = new Blob([generatedScript], { type: 'text/python' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = 'agent.py'; a.click(); URL.revokeObjectURL(url);
    };

    const getWindowsPythonServiceCode = () => {
        const sanitizedPythonPath = winServicePythonPath.replace(/\\/g, '\\\\');
        const sanitizedAgentPath = winServiceAgentDir.replace(/\\/g, '\\\\') + '\\\\agent.py';
        const sanitizedLogPath = winServiceAgentDir.replace(/\\/g, '\\\\') + '\\\\service.log';

        return `# coding: utf-8
import win32serviceutil
import win32service
import win32event
import servicemanager
import subprocess
import os
import sys
import time
import logging

PYTHON_EXE = r"${sanitizedPythonPath}"
AGENT_PATH = r"${sanitizedAgentPath}"
LOG_PATH = r"${sanitizedLogPath}"

logging.basicConfig(filename=LOG_PATH, level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class AgentPythonService(win32serviceutil.ServiceFramework):
    _svc_name_ = "ServicoCRMMonitor"
    _svc_display_name_ = "Servico Monitor CRM (agent.py)"
    _svc_description_ = "Executa o script agent.py localizado na pasta CRM Monitor."

    def __init__(self, args):
        super().__init__(args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.process = None

    def SvcStop(self):
        logging.info("Parando servico...")
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        if self.process:
            try: self.process.terminate()
            except: pass

    def SvcDoRun(self):
        logging.info("Servico iniciado.")
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STARTED, (self._svc_name_, ""))
        self.main()

    def main(self):
        while True:
            if win32event.WaitForSingleObject(self.stop_event, 0) == win32event.WAIT_OBJECT_0: break
            try:
                logging.info("Iniciando agent.py...")
                self.process = subprocess.Popen([PYTHON_EXE, AGENT_PATH], cwd=os.path.dirname(AGENT_PATH))
                self.process.wait()
                time.sleep(5)
            except Exception as e:
                logging.error(f"Erro: {e}")
                time.sleep(5)

if __name__ == "__main__":
    win32serviceutil.HandleCommandLine(AgentPythonService)`;
    };

    const downloadServiceInstallScript = () => {
        const blob = new Blob([getWindowsPythonServiceCode()], { type: 'text/python' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = 'service_install.py'; a.click(); URL.revokeObjectURL(url);
    };

    // --- COMPONENTES DE UI ---
    const TabButton = ({ id, label, icon: Icon }: any) => (
        <button 
            onClick={() => setActiveTab(id)} 
            className={`flex items-center gap-2 px-6 py-3 font-medium text-sm transition-all border-b-2 ${activeTab === id ? 'border-blue-500 text-blue-400 bg-blue-900/10' : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'}`}
        >
            <Icon className="w-4 h-4" /> {label}
        </button>
    );

    return (
        <div className="space-y-6 pb-20 animate-in fade-in duration-500">
            {notification && (
                <div className={`fixed top-20 right-8 z-50 text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-3 ${notification.type === 'success' ? 'bg-emerald-600' : notification.type === 'warning' ? 'bg-amber-600' : 'bg-red-600'}`}>
                    {notification.type === 'success' ? <Check className="w-5 h-5"/> : <AlertTriangle className="w-5 h-5"/>}
                    {notification.message}
                </div>
            )}

            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-white mb-1">Assistente de Instalação</h1>
                    <p className="text-slate-400 text-sm">
                        {isEditMode ? `Editando: ${originalHostname || '...'}` : 'Configure o backend e gere novos agentes.'}
                    </p>
                </div>
                {!isAllowedToEdit && (
                    <div className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg flex items-center gap-2 text-slate-400 text-xs">
                        <Eye className="w-4 h-4" /> Modo Leitura
                    </div>
                )}
            </div>

            {/* Navegação por Abas */}
            <div className="flex border-b border-slate-800 bg-slate-900/50 rounded-t-xl overflow-hidden">
                <TabButton id="infra" label="1. Infraestrutura" icon={Server} />
                <TabButton id="config" label="2. Configuração do Agente" icon={Settings2} />
                <TabButton id="deploy" label="3. Implantação (Scripts)" icon={Download} />
            </div>

            {/* CONTEÚDO DAS ABAS */}
            
            {/* 1. INFRAESTRUTURA */}
            {activeTab === 'infra' && (
                <div className="space-y-6">
                    <div className="bg-slate-900 border border-indigo-500/30 rounded-xl overflow-hidden shadow-lg shadow-indigo-500/5">
                        <div className="p-4 border-b border-slate-800 bg-slate-950/50 flex justify-between items-center">
                            <h3 className="font-medium text-indigo-400 flex items-center gap-2"><Terminal className="w-4 h-4"/> Código do Servidor Backend (Node.js)</h3>
                            <button onClick={() => copyToClipboard(backendServerCode)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-colors">Copiar Código</button>
                        </div>
                        <div className="p-0 bg-[#0d1117]">
                            <pre className="text-xs text-slate-400 overflow-x-auto p-4 max-h-[400px] custom-scrollbar leading-relaxed">{backendServerCode}</pre>
                        </div>
                        <div className="p-4 bg-indigo-900/10 border-t border-indigo-500/10 text-xs text-indigo-300 flex gap-2">
                            <span>ℹ️</span>
                            <span>Salve este código como <code>server.js</code> no seu servidor. Instale as dependências: <code>npm install express cors pg jsonwebtoken</code></span>
                        </div>
                    </div>
                </div>
            )}

            {/* 2. CONFIGURAÇÃO */}
            {activeTab === 'config' && (
                <div className="space-y-6">
                    {isLoadingHost ? (
                        <div className="text-center py-12 text-slate-500"><Loader2 className="w-8 h-8 animate-spin mx-auto mb-2"/> Carregando dados do host...</div>
                    ) : (
                        <>
                            {/* Status Global do Host */}
                            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row justify-between items-center gap-4">
                                <div className="flex items-center gap-4">
                                    <div className={`p-3 rounded-full ${isHostMonitoringEnabled ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-700/30 text-slate-500'}`}>
                                        <Monitor className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <h4 className="font-medium text-white">Monitoramento do Agente</h4>
                                        <p className="text-xs text-slate-400">Ative ou pause a coleta de dados para este host.</p>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => isAllowedToEdit && setIsHostMonitoringEnabled(!isHostMonitoringEnabled)}
                                    disabled={!isAllowedToEdit}
                                    className={`relative inline-flex h-7 w-14 items-center rounded-full transition-colors ${isHostMonitoringEnabled ? 'bg-emerald-500' : 'bg-slate-700'} disabled:opacity-50`}
                                >
                                    <span className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${isHostMonitoringEnabled ? 'translate-x-8' : 'translate-x-1'}`} />
                                </button>
                            </div>

                            {/* Lista de Serviços */}
                            <div className="space-y-4">
                                <div className="flex justify-between items-end pb-2 border-b border-slate-800">
                                    <h3 className="text-lg font-semibold text-white">Serviços Monitorados</h3>
                                    {isAllowedToEdit && (
                                        <div className="flex gap-2">
                                            <select 
                                                value={selectedServiceTypeKey} 
                                                onChange={e => setSelectedServiceTypeKey(e.target.value)} 
                                                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500"
                                            >
                                                {serviceTypes.map(st => (<option key={st.type_key} value={st.type_key}>{st.display_name}</option>))}
                                            </select>
                                            <button onClick={handleAddService} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg flex items-center gap-2 transition-colors">
                                                <Plus className="w-4 h-4"/> Adicionar
                                            </button>
                                        </div>
                                    )}
                                </div>

                                {services.length === 0 ? (
                                    <div className="text-center py-16 border-2 border-dashed border-slate-800 rounded-xl">
                                        <ServerCog className="w-10 h-10 text-slate-700 mx-auto mb-3" />
                                        <p className="text-slate-500">Nenhum serviço configurado.</p>
                                    </div>
                                ) : (
                                    <div className="grid grid-cols-1 gap-4">
                                        {services.map((service) => {
                                            const typeInfo = serviceTypes.find(st => st.type_key === service.typeKey);
                                            const Icon = serviceTypeIcons[service.typeKey] || Cog;
                                            
                                            return (
                                                <div key={service.id} className={`bg-slate-900 border rounded-xl transition-all ${service.enabled ? 'border-slate-700 hover:border-blue-500/50' : 'border-slate-800 opacity-60'}`}>
                                                    <div className="p-4">
                                                        <div className="flex justify-between items-start mb-4">
                                                            <div className="flex items-center gap-3">
                                                                <div className="p-2 bg-slate-800 rounded-lg text-blue-400"><Icon className="w-5 h-5"/></div>
                                                                <div>
                                                                    <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">{typeInfo?.display_name}</span>
                                                                    <input 
                                                                        value={service.name} 
                                                                        onChange={e => handleUpdateService(service.id, 'name', e.target.value)}
                                                                        disabled={!isAllowedToEdit}
                                                                        className="block bg-transparent text-slate-200 font-medium text-lg outline-none border-b border-transparent focus:border-blue-500 transition-all w-full"
                                                                        placeholder="Nome do Serviço"
                                                                    />
                                                                </div>
                                                            </div>
                                                            {isAllowedToEdit && (
                                                                <div className="flex items-center gap-2">
                                                                    <button onClick={() => handleUpdateService(service.id, 'enabled', !service.enabled)} className={`p-2 rounded-lg transition-colors ${service.enabled ? 'text-emerald-400 hover:bg-emerald-500/10' : 'text-slate-600 hover:text-slate-400'}`} title={service.enabled ? "Desativar" : "Ativar"}>
                                                                        {service.enabled ? <ToggleRight className="w-5 h-5"/> : <ToggleLeft className="w-5 h-5"/>}
                                                                    </button>
                                                                    <button onClick={() => handleRemoveService(service.id)} className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors" title="Remover">
                                                                        <Trash2 className="w-5 h-5"/>
                                                                    </button>
                                                                </div>
                                                            )}
                                                        </div>
                                                        
                                                        {/* Campos do Formulário */}
                                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/50 p-4 rounded-lg border border-slate-800/50">
                                                            {typeInfo?.config_schema.fields.map(field => (
                                                                <div key={field.name} className={field.span === 'full' ? 'md:col-span-2' : ''}>
                                                                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1 ml-1">{field.label}</label>
                                                                    <div className="relative">
                                                                        <input
                                                                            type={field.type}
                                                                            value={service.values[field.name] || ''}
                                                                            onChange={e => handleUpdateService(service.id, field.name, e.target.value)}
                                                                            disabled={!isAllowedToEdit}
                                                                            className={`w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-300 outline-none focus:border-blue-500 transition-all ${service.values[field.name] === '__PROTECTED__' ? 'text-emerald-500 font-mono italic' : ''}`}
                                                                            placeholder={field.placeholder}
                                                                        />
                                                                        {service.values[field.name] === '__PROTECTED__' && <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 text-emerald-500"/>}
                                                                    </div>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>

                            {/* Rodapé de Ação */}
                            <div className="sticky bottom-0 bg-slate-950/90 backdrop-blur p-4 border-t border-slate-800 mt-8 flex justify-end gap-4 rounded-xl">
                                {isEditMode && isAllowedToEdit && (
                                    <button onClick={handleSaveConfigOnly} className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg transition-colors border border-slate-700">
                                        Salvar Alterações
                                    </button>
                                )}
                                {isAllowedToEdit && (
                                    <button onClick={handleGenerateScript} className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-lg transition-colors shadow-lg shadow-emerald-900/20 flex items-center gap-2">
                                        <Wand2 className="w-4 h-4" />
                                        {isEditMode ? 'Salvar e Gerar Script' : 'Gerar Script'}
                                    </button>
                                )}
                            </div>
                        </>
                    )}
                </div>
            )}

            {/* 3. IMPLANTAÇÃO */}
            {activeTab === 'deploy' && (
                <div className="space-y-8">
                    {/* Card do Agente (Condicional) */}
                    {generatedScript ? (
                        <div className="bg-slate-900 border border-blue-500/30 rounded-xl overflow-hidden shadow-lg shadow-blue-900/10">
                            <div className="p-4 border-b border-slate-800 bg-slate-950/50 flex justify-between items-center">
                                <h3 className="font-medium text-blue-400 flex items-center gap-2"><Code2 className="w-4 h-4"/> 1. Script do Agente (agent.py)</h3>
                                <div className="flex gap-2">
                                    <button onClick={() => copyToClipboard(generatedScript)} className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded transition-colors">Copiar</button>
                                    <button onClick={downloadAgentScript} className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded transition-colors flex items-center gap-1"><Download className="w-3 h-3"/> Baixar</button>
                                </div>
                            </div>
                            <div className="bg-[#0d1117] p-4 max-h-[300px] overflow-y-auto custom-scrollbar">
                                <pre className="text-xs text-slate-400 font-mono">{generatedScript}</pre>
                            </div>
                        </div>
                    ) : (
                        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-center">
                            <Settings2 className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                            <h3 className="font-medium text-slate-300">Script do Agente (agent.py)</h3>
                            <p className="text-sm text-slate-500 mb-4">Configure os serviços na aba "Configuração" para gerar este arquivo.</p>
                            <button onClick={() => setActiveTab('config')} className="text-xs px-4 py-2 bg-slate-800 hover:bg-slate-700 text-blue-400 rounded-lg transition-colors">Ir para Configuração</button>
                        </div>
                    )}

                    {/* Card de Serviço (Sempre Visível) */}
                    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                        <div className="p-4 border-b border-slate-800 bg-slate-950/50">
                            <h3 className="font-medium text-white flex items-center gap-2"><Laptop className="w-4 h-4"/> 2. Instalação como Serviço</h3>
                        </div>
                        <div className="p-6">
                            <div className="flex gap-6 mb-6 border-b border-slate-800">
                                <button onClick={() => setInstallOs('linux')} className={`pb-3 text-sm font-medium transition-colors relative ${installOs === 'linux' ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`}>
                                    Linux (Systemd)
                                    {installOs === 'linux' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-500 rounded-t-full"></span>}
                                </button>
                                <button onClick={() => setInstallOs('windows-service')} className={`pb-3 text-sm font-medium transition-colors relative ${installOs === 'windows-service' ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`}>
                                    Windows (PyWin32)
                                    {installOs === 'windows-service' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-500 rounded-t-full"></span>}
                                </button>
                            </div>

                            {installOs === 'windows-service' && (
                                <div className="space-y-4 animate-in fade-in">
                                    <div className="bg-amber-900/20 border border-amber-500/20 p-3 rounded-lg flex items-start gap-3">
                                        <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0"/>
                                        <div>
                                            <p className="text-sm text-amber-200 font-medium">Requisito: PyWin32</p>
                                            <p className="text-xs text-amber-400/80">Execute: <code>pip install pywin32</code></p>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-medium text-slate-400 mb-1">Caminho Python</label>
                                            <input type="text" value={winServicePythonPath} onChange={e => setWinServicePythonPath(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-slate-300"/>
                                        </div>
                                        <div>
                                            <label className="block text-xs font-medium text-slate-400 mb-1">Diretório do Agente</label>
                                            <input type="text" value={winServiceAgentDir} onChange={e => setWinServiceAgentDir(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-slate-300"/>
                                        </div>
                                    </div>
                                    <button onClick={downloadServiceInstallScript} className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium rounded-lg border border-slate-700 transition-colors flex justify-center items-center gap-2">
                                        <Download className="w-4 h-4"/> Baixar Script de Instalação (service_install.py)
                                    </button>
                                    <div className="text-xs text-slate-500 mt-2">
                                        <strong>Como usar:</strong> <br/>1. Salve na pasta do agente. <br/>2. Abra CMD como Admin. <br/>3. <code>python service_install.py install</code> <br/>4. <code>python service_install.py start</code>
                                    </div>
                                </div>
                            )}
                            
                            {installOs === 'linux' && (
                                <div className="bg-[#0d1117] p-4 rounded-lg border border-slate-800 font-mono text-xs text-slate-400">
                                    <p className="mb-2 text-slate-500"># /etc/systemd/system/intellimonitor.service</p>
                                    <pre className="text-slate-300 mb-4">
{`[Unit]
Description=IntelliMonitor Agent
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/monitor
ExecStart=/usr/bin/python3 /opt/monitor/agent.py
Restart=always

[Install]
WantedBy=multi-user.target`}
                                    </pre>
                                    <p className="text-emerald-500">sudo systemctl enable --now intellimonitor</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default InstallGuide;
