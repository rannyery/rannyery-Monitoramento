
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Save, Server, Clock, Activity, AlertCircle, CheckCircle2, ArrowLeft, Database, Loader2, RotateCw, Globe, Mic, Upload, Lock } from 'lucide-react';
import { getRefreshInterval, getBackendUrl, isBackendUrlLocked } from '../services/mockData';
import { isAuthenticated } from '../services/authService';
import { isGeminiKeyDetected } from '../services/voiceService';

const Settings: React.FC = () => {
    const [backendUrl, setBackendUrl] = useState('');
    const [refreshInterval, setRefreshInterval] = useState(5000);
    const [saved, setSaved] = useState(false);
    const [isLocked, setIsLocked] = useState(false);
    
    // Estados para teste de conexão
    const [testingConnection, setTestingConnection] = useState(false);
    const [testResult, setTestResult] = useState<{ success: boolean; message: React.ReactNode } | null>(null);
    
    // Estados para configurações remotas (Banco de Dados)
    const [remoteSettings, setRemoteSettings] = useState<{ server_ip: string, server_port: string } | null>(null);
    const [loadingRemote, setLoadingRemote] = useState(false);
    const [savingRemote, setSavingRemote] = useState(false);
    const [remoteError, setRemoteError] = useState<string | null>(null);
    const [detectingIp, setDetectingIp] = useState(false);
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // Estado do Diagnóstico
    const [geminiStatus, setGeminiStatus] = useState(false);

    const navigate = useNavigate();
    const isAuth = isAuthenticated();

    useEffect(() => {
        // Carrega a URL atual
        const url = getBackendUrl();
        setBackendUrl(url || ''); // Garante que não seja null
        setRefreshInterval(getRefreshInterval());
        setGeminiStatus(isGeminiKeyDetected());
        
        const locked = isBackendUrlLocked();
        setIsLocked(locked);

        // Só carrega settings remotos se estiver logado, para evitar chamadas desnecessárias ou erros
        if (url && isAuth) {
            fetchRemoteSettings(url);
        }
    }, [isAuth]);

    const fetchRemoteSettings = async (url: string) => {
        setLoadingRemote(true);
        setRemoteError(null);
        try {
            // Garante URL limpa
            const cleanUrl = url.endsWith('/') ? url.slice(0, -1) : url;
            // Adiciona timestamp para evitar cache do navegador
            const response = await fetch(`${cleanUrl}/api/system-settings?_t=${Date.now()}`, {
                headers: { 'Cache-Control': 'no-cache', 'Pragma': 'no-cache' }
            });
            
            if (response.ok) {
                const data = await response.json();
                setRemoteSettings({
                    server_ip: data.server_ip || '',
                    server_port: data.server_port || ''
                });
            } else {
                setRemoteSettings({ server_ip: '', server_port: '' });
            }
        } catch (error) {
            setRemoteError("Não foi possível carregar as configurações do banco de dados. Verifique a conexão.");
            setRemoteSettings({ server_ip: '', server_port: '' });
        } finally {
            setLoadingRemote(false);
        }
    };

    const handleSaveLocal = () => {
        if (isLocked) {
             alert("A URL do backend está definida no arquivo env-config.js e não pode ser alterada aqui.");
             return;
        }

        let urlToSave = backendUrl.trim();
        if (urlToSave.endsWith('/')) {
            urlToSave = urlToSave.slice(0, -1);
        }
        
        localStorage.setItem('intelli_backend_url', urlToSave);
        localStorage.setItem('intelli_refresh_interval', refreshInterval.toString());
        
        // Atualiza estado local
        setBackendUrl(urlToSave);
        setSaved(true);
        
        // Força o reload da página após 1 segundo para aplicar as mudanças em todo o sistema (API services)
        setTimeout(() => {
            window.location.reload();
        }, 1000);
    };

    const handleImportJson = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const content = e.target?.result as string;
                const config = JSON.parse(content);
                
                if (config.backendUrl) {
                    let url = config.backendUrl.trim();
                    if (url.endsWith('/')) url = url.slice(0, -1);
                    
                    setBackendUrl(url);
                    localStorage.setItem('intelli_backend_url', url);
                    
                    alert(`Configuração importada com sucesso! Backend definido para: ${url}`);
                    
                    // Reload para aplicar
                    window.location.reload();
                } else {
                    alert("Arquivo JSON inválido. O arquivo deve conter a chave 'backendUrl'.");
                }
            } catch (err) {
                alert("Erro ao ler arquivo JSON.");
                console.error(err);
            }
        };
        reader.readAsText(file);
        // Limpa o input para permitir selecionar o mesmo arquivo novamente
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleSaveRemote = async () => {
        if (!remoteSettings || !backendUrl) return;
        
        setSavingRemote(true);
        try {
            const cleanUrl = backendUrl.endsWith('/') ? backendUrl.slice(0, -1) : backendUrl;
            
            const payload = {
                ip: remoteSettings.server_ip,
                port: remoteSettings.server_port
            };
            
            const response = await fetch(`${cleanUrl}/api/system-settings`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            
            if (response.ok) {
                setSaved(true);
                setTimeout(() => setSaved(false), 2500);
                // Recarrega para confirmar o salvamento
                fetchRemoteSettings(backendUrl);
            } else {
                alert("Erro ao salvar no banco de dados. Verifique o log do servidor.");
            }
        } catch (error) {
            alert("Erro de conexão ao tentar salvar no banco.");
        } finally {
            setSavingRemote(false);
        }
    };
    
    const syncToLocal = () => {
        if (remoteSettings && remoteSettings.server_ip && remoteSettings.server_port) {
            const newUrl = `https://${remoteSettings.server_ip}:${remoteSettings.server_port}`;
            setBackendUrl(newUrl);
            localStorage.setItem('intelli_backend_url', newUrl);
            // Reload para aplicar
            alert("URL atualizada! O sistema irá reiniciar para aplicar a nova conexão.");
            window.location.reload();
        }
    };
    
    const detectExternalIp = async () => {
        setDetectingIp(true);
        try {
            const res = await fetch('https://api.ipify.org?format=json');
            const data = await res.json();
            setRemoteSettings(prev => prev ? ({...prev, server_ip: data.ip}) : { server_ip: data.ip, server_port: '' });
        } catch (e) {
            alert('Não foi possível detectar o IP externo.');
        } finally {
            setDetectingIp(false);
        }
    };

    const testConnection = async () => {
        setTestingConnection(true);
        setTestResult(null);
        
        let urlToTest = backendUrl.trim();
        if (!urlToTest) {
            setTestResult({ success: false, message: "URL do backend não pode estar vazia." });
            setTestingConnection(false);
            return;
        }
        if (urlToTest.endsWith('/')) urlToTest = urlToTest.slice(0, -1);

        if (window.location.protocol === 'https:' && urlToTest.startsWith('http:')) {
             setTestResult({
                success: false,
                message: "Bloqueio de Segurança: Não é possível conectar a um backend HTTP inseguro a partir deste painel HTTPS (Mixed Content)."
            });
            setTestingConnection(false);
            return;
        }

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);

            const response = await fetch(`${urlToTest}/`, {
                method: 'GET',
                mode: 'cors',
                credentials: 'omit',
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            if (response.ok) {
                const text = await response.text();
                setTestResult({ success: true, message: `Conectado! Resposta: "${text.slice(0, 50)}..."` });
            } else {
                setTestResult({ success: false, message: `Erro HTTP: ${response.status} ${response.statusText}` });
            }
        } catch (error: any) {
            let msg = error.message || 'Falha desconhecida';
            if (error.name === 'AbortError') {
                 setTestResult({ success: false, message: 'Erro: Tempo limite esgotado (5s). O servidor não respondeu.' });
            } else if (error.name === 'TypeError' && msg === 'Failed to fetch') {
                if (urlToTest.startsWith('https://')) {
                    const CertErrorMessage = (
                        <>
                            A conexão falhou. Em HTTPS, isso geralmente indica um certificado SSL não confiável.
                            <a href={urlToTest} target="_blank" rel="noopener noreferrer" className="font-bold text-blue-400 hover:underline mx-1">
                                Abra a URL em uma nova aba para aceitar o risco
                            </a>
                            e depois tente testar novamente.
                        </>
                    );
                    setTestResult({ success: false, message: CertErrorMessage });
                } else {
                    setTestResult({ success: false, message: 'Erro: Falha na rede. Verifique se o IP/Porta estão corretos e se o servidor está rodando.' });
                }
            } else {
               setTestResult({ success: false, message: `Erro: ${msg}` });
            }
        } finally {
            setTestingConnection(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4 relative">
             <div className="w-full max-w-2xl">
                 <button 
                    onClick={() => navigate(isAuth ? '/' : '/login')} 
                    className="absolute top-4 left-4 sm:top-auto sm:-left-8 sm:-translate-x-full flex items-center gap-2 text-slate-400 hover:text-slate-200 transition-colors text-sm"
                >
                    <ArrowLeft className="w-4 h-4" /> 
                    {isAuth ? 'Voltar ao Dashboard' : 'Voltar para Login'}
                </button>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-8">
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-2xl font-bold text-white">Configurações</h1>
                            <p className="text-slate-400 mt-1">
                                Ajuste as configurações globais e de conexão.
                            </p>
                        </div>
                        <input 
                            type="file" 
                            accept=".json" 
                            ref={fileInputRef} 
                            onChange={handleImportJson} 
                            className="hidden" 
                        />
                        <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm rounded-lg transition-colors border border-slate-700"
                        >
                            <Upload className="w-4 h-4" /> Importar JSON
                        </button>
                    </div>

                    {/* Diagnóstico do Sistema */}
                    <div className="space-y-4">
                        <div className="flex items-center gap-2 text-white font-semibold pb-2 border-b border-slate-800">
                            <Activity className="w-5 h-5 text-indigo-500" />
                            <h2>Diagnóstico do Sistema</h2>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className={`p-4 rounded-lg border flex items-center justify-between ${geminiStatus ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-amber-500/10 border-amber-500/20'}`}>
                                <div className="flex items-center gap-3">
                                    <div className={`p-2 rounded-lg ${geminiStatus ? 'bg-emerald-500/20' : 'bg-amber-500/20'}`}>
                                        <Mic className={`w-5 h-5 ${geminiStatus ? 'text-emerald-500' : 'text-amber-500'}`} />
                                    </div>
                                    <div>
                                        <h3 className={`font-medium ${geminiStatus ? 'text-emerald-400' : 'text-amber-400'}`}>IA de Voz (Gemini)</h3>
                                        <p className="text-xs text-slate-400">{geminiStatus ? 'Conectado e Ativo' : 'Voz do Navegador (Fallback)'}</p>
                                    </div>
                                </div>
                                {geminiStatus ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <AlertCircle className="w-5 h-5 text-amber-500" />}
                            </div>
                        </div>
                    </div>

                    {/* Configurações Locais (Navegador) */}
                    <div className="space-y-6">
                        <div className="flex items-center gap-2 text-white font-semibold pb-2 border-b border-slate-800">
                            <Server className="w-5 h-5 text-blue-500" />
                            <h2>Conexão Local (Navegador)</h2>
                        </div>
                        
                        <div>
                            <label htmlFor="backendUrl" className="block text-sm font-medium text-slate-300 mb-2 flex justify-between">
                                <span>URL do Servidor Backend</span>
                                {isLocked && <span className="text-amber-500 flex items-center gap-1 text-xs"><Lock className="w-3 h-3"/> Gerenciado por env-config.js</span>}
                            </label>
                            <div className="flex gap-3">
                                <div className="relative flex-1">
                                    <Server className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                                    <input
                                        id="backendUrl"
                                        type="text"
                                        value={backendUrl}
                                        onChange={(e) => setBackendUrl(e.target.value)}
                                        disabled={isLocked}
                                        className={`w-full bg-slate-950 border rounded-lg py-3 pl-10 pr-4 text-slate-200 focus:outline-none transition-colors ${isLocked ? 'border-amber-900/50 text-slate-500 cursor-not-allowed' : 'border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500'}`}
                                        placeholder="https://seu-ip:5077"
                                    />
                                </div>
                                <button
                                    onClick={testConnection}
                                    disabled={testingConnection || !backendUrl}
                                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50"
                                >
                                    {testingConnection ? <Activity className="w-4 h-4 animate-spin" /> : <Activity className="w-4 h-4" />}
                                    {testingConnection ? '...' : 'Testar'}
                                </button>
                            </div>
                            {testResult && (
                                <div className={`mt-3 p-3 rounded-lg text-sm flex items-start gap-2 ${testResult.success ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
                                    {testResult.success ? <CheckCircle2 className="w-5 h-5 flex-shrink-0" /> : <AlertCircle className="w-5 h-5 flex-shrink-0" />}
                                    <div>{testResult.message}</div>
                                </div>
                            )}
                        </div>

                        <div>
                            <label htmlFor="refreshInterval" className="block text-sm font-medium text-slate-300 mb-2">
                                Intervalo de Atualização Automática
                            </label>
                            <div className="relative">
                                <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                                <select
                                    id="refreshInterval"
                                    value={refreshInterval}
                                    onChange={(e) => setRefreshInterval(Number(e.target.value))}
                                    className="w-full bg-slate-950 border border-slate-800 rounded-lg py-3 pl-10 pr-4 text-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors appearance-none"
                                >
                                    <option value="1000">1 segundo (Tempo Real)</option>
                                    <option value="3000">3 segundos (Rápido)</option>
                                    <option value="5000">5 segundos (Padrão)</option>
                                    <option value="10000">10 segundos</option>
                                    <option value="60000">1 minuto</option>
                                </select>
                            </div>
                        </div>
                         <div className="flex justify-end gap-3">
                            {!isLocked && (
                                <button
                                    onClick={handleSaveLocal}
                                    disabled={saved}
                                    className={`flex items-center justify-center gap-2 px-6 py-2.5 font-medium rounded-lg transition-colors ${saved ? 'bg-emerald-600 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
                                >
                                    {saved ? (
                                        <>
                                            <CheckCircle2 className="w-4 h-4" />
                                            Salvo! Recarregando...
                                        </>
                                    ) : (
                                        <>
                                            <Save className="w-4 h-4" />
                                            Salvar Configuração Local
                                        </>
                                    )}
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Configurações Remotas (Banco de Dados) - Apenas se Logado */}
                    {isAuth && (
                         <div className="space-y-6 pt-6 border-t border-slate-800">
                            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                                <div className="flex items-center gap-2 text-white font-semibold">
                                    <Database className="w-5 h-5 text-emerald-500" />
                                    <h2>Configuração Global (Banco de Dados)</h2>
                                </div>
                                <button 
                                    onClick={() => backendUrl && fetchRemoteSettings(backendUrl)} 
                                    className="text-xs flex items-center gap-1 text-slate-400 hover:text-white transition-colors"
                                    disabled={loadingRemote}
                                >
                                    <RotateCw className={`w-3 h-3 ${loadingRemote ? 'animate-spin' : ''}`} /> Atualizar
                                </button>
                            </div>
                            
                            {remoteError ? (
                                 <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 text-center text-sm text-slate-500">
                                    <p className="mb-2">{remoteError}</p>
                                    <button onClick={() => backendUrl && fetchRemoteSettings(backendUrl)} className="text-blue-400 underline">Tentar Novamente</button>
                                 </div>
                            ) : (
                                <div className="bg-slate-950/50 rounded-lg border border-slate-800 p-4">
                                    <p className="text-sm text-slate-400 mb-4">
                                        Estas configurações ficam salvas no banco de dados. Elas definem a "Fonte da Verdade" para sincronização automática.
                                    </p>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-medium text-slate-400 mb-1">
                                                IP do Servidor (Oficial)
                                                <button 
                                                    onClick={detectExternalIp}
                                                    className="ml-2 text-[10px] text-blue-400 hover:underline inline-flex items-center gap-0.5"
                                                    title="Usa um serviço externo para descobrir seu IP público"
                                                >
                                                    {detectingIp ? <Loader2 className="w-3 h-3 animate-spin"/> : <Globe className="w-3 h-3"/>}
                                                    Detectar Externo
                                                </button>
                                            </label>
                                            <input 
                                                type="text" 
                                                value={remoteSettings?.server_ip || ''} 
                                                onChange={e => setRemoteSettings(prev => prev ? ({...prev, server_ip: e.target.value}) : { server_ip: e.target.value, server_port: '' })}
                                                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:border-emerald-500 outline-none"
                                                placeholder="Ex: 203.0.113.45"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-medium text-slate-400 mb-1">Porta (Oficial)</label>
                                            <input 
                                                type="text" 
                                                value={remoteSettings?.server_port || ''}
                                                onChange={e => setRemoteSettings(prev => prev ? ({...prev, server_port: e.target.value}) : { server_ip: '', server_port: e.target.value })}
                                                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:border-emerald-500 outline-none"
                                                placeholder="Ex: 5077"
                                            />
                                        </div>
                                    </div>
                                    
                                    <div className="mt-4 flex justify-between items-center">
                                         {!isLocked && (
                                             <button 
                                                onClick={syncToLocal}
                                                disabled={!remoteSettings?.server_ip}
                                                className="text-sm text-blue-400 hover:text-blue-300 flex items-center gap-1 disabled:opacity-50"
                                             >
                                                 <ArrowLeft className="w-3 h-3" /> Copiar para meu navegador agora
                                             </button>
                                         )}
                                         
                                         <button
                                            onClick={handleSaveRemote}
                                            disabled={savingRemote}
                                            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50 shadow-lg shadow-emerald-900/20"
                                         >
                                             {savingRemote ? <Loader2 className="w-4 h-4 animate-spin"/> : <Save className="w-4 h-4" />}
                                             Salvar Definitivamente
                                         </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
};

export default Settings;
