
import React, { useEffect, useState } from 'react';
import { Alert, Host } from '../types';
import { getAlerts, getHosts, fetchAndUpdateData, getRefreshInterval } from '../services/mockData';
import StatusBadge from '../components/StatusBadge';
import { Link } from 'react-router-dom';
import { Search, Filter, Calendar } from 'lucide-react';

const AlertsPage: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [hosts, setHosts] = useState<Host[]>([]);
  const [filterType, setFilterType] = useState<'all' | 'active' | 'resolved'>('all');
  
  // Filters
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]); // Default Today
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]); // Default Today
  const [selectedHostId, setSelectedHostId] = useState('all');

  const refreshData = async () => {
      // Ensure backend data is somewhat fresh
      await fetchAndUpdateData(); 
      
      const [alertsData, hostsData] = await Promise.all([
          getAlerts({ start: startDate, end: endDate, hostId: selectedHostId }),
          getHosts()
      ]);
      setHosts(hostsData);
      setAlerts(alertsData);
  };

  useEffect(() => {
    refreshData();
    const intervalMs = getRefreshInterval();
    const interval = setInterval(refreshData, intervalMs);
    return () => clearInterval(interval);
  }, [startDate, endDate, selectedHostId]);

  const filteredAlerts = alerts.filter(a => {
      if (filterType === 'active') return !a.resolved;
      if (filterType === 'resolved') return a.resolved;
      return true;
  });

  const formatTime = (ts: number) => new Date(ts).toLocaleString('pt-BR');

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h1 className="text-2xl font-bold text-white">Histórico de Alertas</h1>
          
          <div className="flex bg-slate-900 border border-slate-800 rounded-lg p-1 self-start">
              <button onClick={() => setFilterType('all')} className={`px-4 py-1.5 text-sm rounded-md transition-colors ${filterType === 'all' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}>Todos</button>
              <button onClick={() => setFilterType('active')} className={`px-4 py-1.5 text-sm rounded-md transition-colors ${filterType === 'active' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}>Ativos</button>
              <button onClick={() => setFilterType('resolved')} className={`px-4 py-1.5 text-sm rounded-md transition-colors ${filterType === 'resolved' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}>Resolvidos</button>
          </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-4 items-end md:items-center">
          <div className="flex-1 w-full grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1 flex items-center gap-1"><Calendar className="w-3 h-3"/> Data Inicial</label>
                  <input 
                    type="date" 
                    value={startDate} 
                    onChange={e => setStartDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  />
              </div>
              <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1 flex items-center gap-1"><Calendar className="w-3 h-3"/> Data Final</label>
                  <input 
                    type="date" 
                    value={endDate} 
                    onChange={e => setEndDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  />
              </div>
              <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1 flex items-center gap-1"><Search className="w-3 h-3"/> Filtrar por Host</label>
                  <select 
                    value={selectedHostId}
                    onChange={e => setSelectedHostId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  >
                      <option value="all">Todos os Hosts</option>
                      {hosts.map(h => (
                          <option key={h.id} value={h.id}>{h.hostname}</option>
                      ))}
                  </select>
              </div>
          </div>
          <button 
            onClick={refreshData}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 flex items-center gap-2 transition-colors"
          >
              <Filter className="w-4 h-4" /> Atualizar
          </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <table className="w-full text-left text-sm">
              <thead className="bg-slate-950/50 text-slate-400 border-b border-slate-800">
                  <tr>
                      <th className="px-6 py-4 font-medium">Severidade</th>
                      <th className="px-6 py-4 font-medium">Ocorrência</th>
                      <th className="px-6 py-4 font-medium">Host</th>
                      <th className="px-6 py-4 font-medium w-1/2">Detalhes</th>
                      <th className="px-6 py-4 font-medium">Status</th>
                  </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                  {filteredAlerts.length === 0 ? (
                      <tr>
                          <td colSpan={5} className="px-6 py-12 text-center text-slate-500">
                              <div className="flex flex-col items-center gap-2">
                                  <Filter className="w-8 h-8 text-slate-700" />
                                  <p>Nenhum alerta encontrado para o período e filtros selecionados.</p>
                              </div>
                          </td>
                      </tr>
                  ) : filteredAlerts.map(alert => {
                      const [alertTitle, ...alertDetails] = alert.message.split(':');
                      const detailsText = alertDetails.join(':').trim();

                      return (
                          <tr key={alert.id} className="hover:bg-slate-800/30 transition-colors">
                              <td className="px-6 py-4">
                                  <StatusBadge status={alert.severity} type="alert" />
                              </td>
                              <td className="px-6 py-4 text-slate-400 whitespace-nowrap">
                                  {formatTime(alert.timestamp)}
                              </td>
                              <td className="px-6 py-4 font-medium text-blue-400">
                                  <Link to={`/hosts/${alert.hostId}`} className="hover:underline">
                                    {alert.hostname}
                                  </Link>
                              </td>
                              <td className="px-6 py-4 text-slate-300">
                                  <p className="font-semibold text-slate-200">{alertTitle}</p>
                                  {detailsText && <p className="text-xs text-slate-400 mt-1 italic">{detailsText}</p>}
                              </td>
                              <td className="px-6 py-4">
                                   {alert.resolved ? (
                                       <div className="flex flex-col">
                                           <StatusBadge status="resolved" />
                                           {alert.resolvedAt && (
                                               <span className="text-xs text-slate-500 mt-1 whitespace-nowrap">
                                                   {formatTime(alert.resolvedAt)}
                                               </span>
                                           )}
                                       </div>
                                   ) : (
                                       <span className="text-amber-500 text-xs font-medium animate-pulse">Ativo</span>
                                   )}
                              </td>
                          </tr>
                      );
                  })}
              </tbody>
          </table>
      </div>
    </div>
  );
};

export default AlertsPage;
