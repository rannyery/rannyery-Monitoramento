
import React from 'react';

// Página descontinuada/removida conforme solicitação do usuário.
// Mantida vazia para evitar erros de importação caso existam referências residuais no bundle.
const NotificationsPage: React.FC = () => {
  return null;
};

export default NotificationsPage;
