
// NOTE: Dynamic import is used inside playNext to prevent "process is not defined" crashes 
// if the library tries to access Node.js globals on top-level import.

// Fila para gerenciar mensagens sequenciais e evitar sobreposição
let audioQueue: string[] = [];
let isPlaying = false;
let audioContext: AudioContext | null = null;
let geminiModule: any = null;
let geminiImportFailed = false;

// Helper para verificar se a chave da API está configurada no ambiente
export const isGeminiKeyDetected = (): boolean => {
    try {
        // @ts-ignore
        if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
            return true;
        }
    } catch(e) {
        return false;
    }
    return false;
};

// Helper para decodificar Base64 (Do sistema Gemini)
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Helper para converter PCM Raw para AudioBuffer (Do sistema Gemini)
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

// Helper para garantir carregamento de vozes (Chrome bug)
const loadVoices = (): Promise<SpeechSynthesisVoice[]> => {
    return new Promise((resolve) => {
        let voices = window.speechSynthesis.getVoices();
        if (voices.length > 0) {
            resolve(voices);
            return;
        }
        window.speechSynthesis.onvoiceschanged = () => {
            voices = window.speechSynthesis.getVoices();
            resolve(voices);
        };
        // Timeout de segurança caso onvoiceschanged não dispare
        setTimeout(() => {
             resolve(window.speechSynthesis.getVoices());
        }, 1000);
    });
};

// Função de Fallback (Voz do Navegador)
// Usada caso a API Key não exista ou falhe
const speakBrowserFallback = async (text: string) => {
    if (!('speechSynthesis' in window)) return;
    
    // Aguarda carregamento das vozes
    const voices = await loadVoices();
    const utterance = new SpeechSynthesisUtterance(text);
    
    // LOGICA DE SELEÇÃO DE VOZ (PRIORIZA VOZES DOCES/NATURAIS)
    
    // 1. Prioridade: Microsoft Maria (Excelente qualidade no Windows)
    let ptVoice = voices.find(v => v.name.includes('Microsoft Maria'));

    // 2. Prioridade: Google Português do Brasil
    if (!ptVoice) {
        ptVoice = voices.find(v => v.name === 'Google Português do Brasil');
    }

    // 3. Prioridade: Qualquer voz feminina PT-BR
    if (!ptVoice) {
        ptVoice = voices.find(v => 
            (v.lang.includes('pt-BR') || v.lang.includes('pt_BR')) && 
            (v.name.includes('Female') || v.name.includes('Feminina'))
        );
    }
    
    // 4. Fallback geral para qualquer voz PT-BR
    if (!ptVoice) {
        ptVoice = voices.find(v => v.lang === 'pt-BR' || v.lang === 'pt_BR');
    }

    if (ptVoice) {
        utterance.voice = ptVoice;
        console.log(`🔊 [Fallback] Usando voz do navegador: ${ptVoice.name}`);
    } else {
        console.warn("🔊 [Fallback] Nenhuma voz PT-BR encontrada. Usando padrão.");
    }
    
    utterance.rate = 1.05; // Ritmo natural
    utterance.pitch = 1.1; // Um pouco mais agudo para soar mais "doce" se for robótica
    
    utterance.onend = () => {
        playNext(); 
    };
    
    utterance.onerror = () => {
        console.warn("Erro no TTS do navegador");
        playNext();
    }

    window.speechSynthesis.speak(utterance);
};

// Processador da Fila de Áudio
const playNext = async () => {
    if (audioQueue.length === 0) {
        isPlaying = false;
        return;
    }

    const text = audioQueue.shift();
    if (!text) {
        playNext();
        return;
    }

    isPlaying = true;

    // Se já falhou a importação anteriormente, usa fallback direto
    if (geminiImportFailed) {
        speakBrowserFallback(text);
        return;
    }

    // Verifica se a chave existe
    if (!isGeminiKeyDetected()) {
        console.log("ℹ️ API Key não detectada. Usando voz do navegador.");
        speakBrowserFallback(text);
        return;
    }

    try {
        // Tenta importar o módulo se ainda não foi carregado
        if (!geminiModule) {
            try {
                // Dynamic Import to safely load the module only when needed
                geminiModule = await import("@google/genai");
            } catch (importError: any) {
                // Check if it's a fetch error
                if (importError.message && importError.message.includes('Failed to fetch')) {
                    console.warn("⚠️ Não foi possível baixar a biblioteca @google/genai (Erro de Rede/CORS). Usando voz do navegador.");
                } else {
                    console.warn("⚠️ Erro ao carregar biblioteca Gemini:", importError);
                }
                geminiImportFailed = true;
                speakBrowserFallback(text);
                return;
            }
        }

        const { GoogleGenAI, Modality } = geminiModule;

        // Inicializa Contexto de Áudio se necessário
        if (!audioContext) {
            audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
        }
        
        // Retoma contexto se estiver suspenso (política de autoplay)
        if (audioContext.state === 'suspended') {
            await audioContext.resume();
        }

        // Recupera a chave novamente
        // @ts-ignore
        const apiKey = process.env.API_KEY; 

        const ai = new GoogleGenAI({ apiKey });

        console.log("🔊 Tentando gerar voz com Gemini (Modelo: Aoede)...");

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        // 'Aoede': Voz mais expressiva, humana e doce disponível.
                        prebuiltVoiceConfig: { voiceName: 'Aoede' }, 
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

        if (!base64Audio) {
            throw new Error("Gemini não retornou dados de áudio.");
        }

        // Decodificação PCM Raw (Especificidade do modelo 2.5 Flash TTS)
        const audioBytes = decode(base64Audio);
        const audioBuffer = await decodeAudioData(audioBytes, audioContext);

        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);

        source.onended = () => {
            playNext();
        };

        source.start();

    } catch (error: any) {
        if (error.message && error.message.includes("Failed to fetch")) {
             console.warn("⚠️ Erro de rede ao conectar com Gemini API. Usando Fallback.");
        } else {
             console.error("⚠️ Erro ao gerar voz com Gemini (Fallback ativado):", error);
        }
        // Se falhar a IA (erro de API, Cota, etc), usa o navegador
        speakBrowserFallback(text);
    }
};

export const speak = (text: string) => {
  // Adiciona à fila
  audioQueue.push(text);
  
  // Se não estiver tocando nada, inicia o processamento
  if (!isPlaying) {
      playNext();
  }
};
