
import { Host, Alert, MetricPoint, OSType, AlertSeverity, UserGroup, User } from '../types';

// --- Configuration ---
const DEFAULT_REFRESH_INTERVAL = 5000;
const DEFAULT_BACKEND_PORT = 5077;

export const getRefreshInterval = (): number => {
  const stored = localStorage.getItem('intelli_refresh_interval');
  return stored ? parseInt(stored, 10) : DEFAULT_REFRESH_INTERVAL;
};

export const getBackendUrl = (): string => {
  // 1. Prioridade: Arquivo de configuração estático (env-config.js)
  // Verifica se existe e se não é uma string vazia
  if (window.INTELLI_CONFIG && window.INTELLI_CONFIG.backendUrl && window.INTELLI_CONFIG.backendUrl.trim().length > 0) {
      return window.INTELLI_CONFIG.backendUrl.trim();
  }

  // 2. Prioridade: LocalStorage
  const stored = localStorage.getItem('intelli_backend_url');
  if (stored && stored !== 'undefined' && stored !== 'null' && stored.trim().length > 0) {
      return stored.trim();
  }
  
  // 3. Fallback: Retorna vazio para obrigar configuração ou hostname atual se preferir
  // Para evitar erros de "não consigo digitar", retornamos string vazia se não houver nada configurado,
  // ou sugerimos o localhost se for desenvolvimento.
  const hostname = window.location.hostname;
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
      return `http://${hostname}:${DEFAULT_BACKEND_PORT}`;
  }
  
  return '';
};

export const isBackendUrlLocked = (): boolean => {
    return !!(window.INTELLI_CONFIG && window.INTELLI_CONFIG.backendUrl && window.INTELLI_CONFIG.backendUrl.trim().length > 0);
};

// --- Sync Logic ---
export const syncLocalConfigWithBackend = async (currentUrl?: string) => {
    // Se estiver travado pelo env-config, não sincroniza/sobrescreve
    if (isBackendUrlLocked()) {
        return window.INTELLI_CONFIG!.backendUrl;
    }

    const urlToUse = currentUrl || getBackendUrl();
    if (!urlToUse) return null;

    const cleanUrl = urlToUse.endsWith('/') ? urlToUse.slice(0, -1) : urlToUse;
    
    try {
        const response = await fetch(`${cleanUrl}/api/system-settings?_t=${Date.now()}`);
        if (response.ok) {
            const settings = await response.json();
            if (settings.server_ip && settings.server_port) {
                // Constrói a URL oficial baseada no banco
                // Nota: Assume HTTP por padrão se não tiver protocolo, mas mantém o protocolo atual se possível
                const protocol = cleanUrl.split('://')[0] || 'http';
                const officialUrl = `${protocol}://${settings.server_ip}:${settings.server_port}`;
                
                if (officialUrl !== cleanUrl) {
                     localStorage.setItem('intelli_backend_url', officialUrl);
                     return officialUrl;
                }
            }
        }
    } catch (e) {
        console.warn("Tentativa de sincronização de config falhou (ignorável):", e);
    }
    return null;
};

// --- In-Memory State ---
let hosts: Host[] = [];
// Alerts are now fetched from DB, but we keep active set for deduplication of API calls during polling
const activeAlertState = new Set<string>();
let lastConnectionError: string | null = null;

// --- Helper for Deep Cloning ---
const deepClone = <T>(obj: T): T => JSON.parse(JSON.stringify(obj));

// --- API Alerts Reporter ---
const reportAlertToBackend = async (hostId: string, alertKey: string, severity: AlertSeverity, message: string, active: boolean) => {
    const backendUrl = getBackendUrl();
    if (!backendUrl) return;

    const cleanUrl = backendUrl.endsWith('/') ? backendUrl.slice(0, -1) : backendUrl;
    
    // Optimization: Check local state to avoid spamming the API with the same status
    const uniqueKey = `${hostId}-${alertKey}`;
    const isActiveLocally = activeAlertState.has(uniqueKey);

    if (active && isActiveLocally) return; // Already reported as active
    if (!active && !isActiveLocally) return; // Already reported as resolved

    try {
        await fetch(`${cleanUrl}/api/alerts/report`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ host_id: hostId, alert_key: alertKey, severity, message, active })
        });
        
        // Update local state on success
        if (active) activeAlertState.add(uniqueKey);
        else activeAlertState.delete(uniqueKey);

    } catch (e) {
        // Silently fail if backend is offline, metrics loop will retry
    }
};

// --- Agent Configuration Service ---
export const saveAgentConfiguration = async (hostname: string, config: { services: any[], monitoringEnabled: boolean }): Promise<{success: boolean, message: string}> => {
  const backendUrl = getBackendUrl();
  if (!backendUrl) return { success: false, message: "URL do backend não configurada." };

  try {
    const response = await fetch(`${backendUrl}/api/config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hostname, ...config })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: `Erro HTTP: ${response.status}` }));
      throw new Error(errorData.error || `Erro HTTP: ${response.status}`);
    }

    return { success: true, message: 'Configuração salva no backend.' };
  } catch (e: any) {
    return { success: false, message: `Falha ao salvar configuração: ${e.message}` };
  }
};

// --- Security Services (Users & Groups) ---

export const getUsers = async (): Promise<User[]> => {
    const backendUrl = getBackendUrl();
    if (!backendUrl) return [];
    try {
        const res = await fetch(`${backendUrl}/api/users`);
        if (!res.ok) throw new Error('Falha ao buscar usuários');
        return await res.json();
    } catch(e) {
        console.error(e);
        return [];
    }
};

export const saveUser = async (user: Partial<User> & { password?: string }): Promise<void> => {
    const backendUrl = getBackendUrl();
    if (!backendUrl) throw new Error("Backend desconectado");
    const method = user.id ? 'PUT' : 'POST';
    const url = user.id ? `${backendUrl}/api/users/${user.id}` : `${backendUrl}/api/users`;
    
    const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    });
    
    if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Erro ao salvar usuário');
    }
};

export const deleteUser = async (id: string): Promise<void> => {
    const backendUrl = getBackendUrl();
    if (!backendUrl) throw new Error("Backend desconectado");
    const res = await fetch(`${backendUrl}/api/users/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Erro ao excluir usuário');
};

export const getUserGroups = async (): Promise<UserGroup[]> => {
    const backendUrl = getBackendUrl();
    if (!backendUrl) return [];
    try {
        const res = await fetch(`${backendUrl}/api/groups`);
        if (!res.ok) throw new Error('Falha ao buscar grupos');
        return await res.json();
    } catch(e) {
        return [];
    }
};

export const saveUserGroup = async (group: Partial<UserGroup>): Promise<void> => {
    const backendUrl = getBackendUrl();
    if (!backendUrl) throw new Error("Backend desconectado");
    const res = await fetch(`${backendUrl}/api/groups`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(group)
    });
    if (!res.ok) throw new Error('Erro ao criar grupo');
};


// --- Data Fetching ---
export const fetchAndUpdateData = async (): Promise<void> => {
  const backendUrl = getBackendUrl();
  
  // Se não tiver URL configurada, não faz nada mas não erro crítico
  if (!backendUrl) {
      lastConnectionError = "URL do Backend não configurada. Vá em Configurações.";
      return;
  }
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    const sanitizedUrl = backendUrl.endsWith('/') ? backendUrl.slice(0, -1) : backendUrl;
    const fetchUrl = `${sanitizedUrl}/api/hosts?_t=${Date.now()}`;

    if (window.location.protocol === 'https:' && sanitizedUrl.startsWith('http:')) {
         throw new Error("MIXED_CONTENT_BLOCK");
    }

    const response = await fetch(fetchUrl, { 
        signal: controller.signal,
        mode: 'cors',
        cache: 'no-store',
        credentials: 'omit'
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
        throw new Error(`Erro HTTP: ${response.status}`);
    }

    const realData = await response.json();
    lastConnectionError = null;
    
    Object.entries(realData).forEach(([hostname, data]: [string, any]) => {
        if (!data || typeof data !== 'object') {
            return;
        }

        let host = hosts.find(h => h.hostname === hostname);

        if (!host) {
            host = {
                id: data.id || 'h-' + Math.random().toString(36).substr(2, 9),
                hostname: hostname,
                ip: data.ip || '0.0.0.0',
                os: (data.os as OSType) || 'linux',
                status: 'offline',
                uptimeSeconds: data.uptimeSeconds || 0,
                lastSeen: 0,
                metrics: { cpu: [], memory: [], networkIn: [], networkOut: [] },
                disks: [],
                services: []
            };
            hosts.push(host);
        }

        const now = Date.now();
        const seenDate = new Date(data.lastSeen);
        
        let validLastSeen = !isNaN(seenDate.getTime()) ? seenDate.getTime() : 0;
        if (validLastSeen > now + 60000) validLastSeen = now;
        
        host.lastSeen = validLastSeen;
        host.uptimeSeconds = data.uptimeSeconds || host.uptimeSeconds;
        host.ip = data.ip || host.ip;
        host.os = (data.os as OSType) || host.os;

        if (data.agentConfig) {
            host.agentConfig = data.agentConfig;
            if (typeof data.agentConfig.monitoringEnabled === 'boolean') {
                host.monitoringEnabled = data.agentConfig.monitoringEnabled;
            }
        }

        const rawServices = Array.isArray(data.services) ? data.services : [];
        if (host.agentConfig?.services) {
            const allowedServices = new Set(
                host.agentConfig.services
                    .filter((s: any) => s.enabled !== false)
                    .map((s: any) => s.name)
            );
            host.services = rawServices.filter((s: any) => allowedServices.has(s.name));
        } else {
            host.services = rawServices;
        }

        const timeSinceLastSeen = now - host.lastSeen;
        if (timeSinceLastSeen > 180000) {
            host.status = 'offline';
        } else if (timeSinceLastSeen > 60000) {
            host.status = 'warning';
        } else {
            host.status = 'healthy';
        }
        
        if (data.latestMetrics) {
                const m = data.latestMetrics;
                
                if (m.disk_total_gb != null && m.disk_used_gb != null) {
                    host.disks = [{ 
                        mount: host.os === 'windows' ? 'C:\\' : '/',
                        total: m.disk_total_gb,
                        used: m.disk_used_gb
                    }];
                    if (host.status !== 'offline' && m.disk_total_gb > 0) {
                        const usage = m.disk_used_gb / m.disk_total_gb;
                        if (usage > 0.95) host.status = 'critical';
                        else if (usage > 0.85 && host.status === 'healthy') host.status = 'warning';
                    }
                }

                const pushMetric = (arr: MetricPoint[], value: number) => {
                    if (Array.isArray(arr)) {
                         arr.push({ timestamp: now, value: Number(value) || 0 });
                         if (arr.length > 40) arr.shift();
                    }
                };

                pushMetric(host.metrics.cpu, m.cpu);
                pushMetric(host.metrics.memory, m.memory);
                
                if (m.net_sent_mb != null && m.net_recv_mb != null) {
                    const prevIn = host._lastNetInData;
                    const prevOut = host._lastNetOutData;
                    
                    if (prevIn && now - prevIn.timestamp < 120000 && m.net_recv_mb >= prevIn.value) {
                        const timeDiffSec = Math.max(1, (now - prevIn.timestamp) / 1000);
                        pushMetric(host.metrics.networkIn, (m.net_recv_mb - prevIn.value) / timeDiffSec);
                    } else {
                        pushMetric(host.metrics.networkIn, 0);
                    }
                    host._lastNetInData = { timestamp: now, value: m.net_recv_mb };

                    if (prevOut && now - prevOut.timestamp < 120000 && m.net_sent_mb >= prevOut.value) {
                            const timeDiffSec = Math.max(1, (now - prevOut.timestamp) / 1000);
                        pushMetric(host.metrics.networkOut, (m.net_sent_mb - prevOut.value) / timeDiffSec);
                    } else {
                        pushMetric(host.metrics.networkOut, 0);
                    }
                    host._lastNetOutData = { timestamp: now, value: m.net_sent_mb };
                }
                
                if (host.status !== 'offline') {
                    if (m.cpu > 95 || m.memory > 98) host.status = 'critical';
                    else if ((m.cpu > 85 || m.memory > 90) && host.status !== 'critical') host.status = 'warning';
                }
        }
    });

    // --- REFACTORED: Alert Generation Logic (Reports to Backend) ---
    const now = Date.now();

    hosts.forEach(host => {
        // 1. Host Status Alerts
        const statusAlertKey = 'host-status';
        
        if (host.status !== 'healthy') {
            const severityMap = { 'warning': 'warning', 'critical': 'critical', 'offline': 'critical' };
            const currentSeverity = severityMap[host.status] as AlertSeverity;
            let message = `Status do Host: O host está em estado '${host.status}'.`;

            const timeSince = now - host.lastSeen;
            if (timeSince > 60000) {
                const seconds = Math.floor(timeSince / 1000);
                message = `Perda de Comunicação: O agente parou de enviar dados há ${seconds}s. Verifique o script.`;
            }
            reportAlertToBackend(host.id, statusAlertKey, currentSeverity, message, true);
        } else {
            reportAlertToBackend(host.id, statusAlertKey, 'info', 'Host recuperado', false);
        }

        // 2. Service Failure Alerts
        (host.services || []).forEach(service => {
            const serviceAlertKey = `service-${service.name}`;
            
            if (service.status === 'failed') {
                const message = `Falha de Serviço '${service.name}': ${service.details || 'N/A'}`;
                reportAlertToBackend(host.id, serviceAlertKey, 'critical', message, true);
            } else {
                reportAlertToBackend(host.id, serviceAlertKey, 'info', `Serviço ${service.name} recuperado`, false);
            }
        });
        
        // 3. Resource Alerts
        const disk = host.disks[0];
        const diskUsage = disk && disk.total > 0 ? (disk.used / disk.total) * 100 : 0;
        const cpuUsage = host.metrics.cpu.slice(-1)[0]?.value ?? 0;
        const memUsage = host.metrics.memory.slice(-1)[0]?.value ?? 0;
        
        const resourceChecks = [
            { key: 'cpu-critical', condition: cpuUsage >= 95, severity: 'critical', message: `CPU Crítico: ${cpuUsage.toFixed(1)}%` },
            { key: 'mem-critical', condition: memUsage >= 98, severity: 'critical', message: `Memória Crítica: ${memUsage.toFixed(1)}%` },
            { key: 'disk-critical', condition: diskUsage >= 95, severity: 'critical', message: `Disco Crítico: ${diskUsage.toFixed(1)}%` },
            { key: 'disk-warning', condition: diskUsage >= 85 && diskUsage < 95, severity: 'warning', message: `Disco Elevado: ${diskUsage.toFixed(1)}%` }
        ];

        resourceChecks.forEach(check => {
             if (check.condition) {
                 reportAlertToBackend(host.id, check.key, check.severity as AlertSeverity, check.message, true);
             } else {
                 reportAlertToBackend(host.id, check.key, 'info', 'Normalizado', false);
             }
        });
    });
    // ----------------------------------------------------------------

  } catch (e: any) {
      let msg = e.message || 'Erro desconhecido';
      
      if (msg === 'MIXED_CONTENT_BLOCK' || (e.name === 'TypeError' && msg === 'Failed to fetch' && window.location.protocol === 'https:' && backendUrl?.startsWith('http:'))) {
          lastConnectionError = "BLOQUEIO DE SEGURANÇA: Seu navegador impediu a conexão porque este painel está em HTTPS e o backend em HTTP. Acesse o painel via HTTP ou configure SSL no backend.";
      } else if (e.name === 'TypeError' && msg === 'Failed to fetch') {
           if (backendUrl && backendUrl.startsWith('https://')) {
               lastConnectionError = `CERT_ERROR`;
           } else {
               lastConnectionError = `Não foi possível conectar a ${backendUrl}. Verifique se o servidor está rodando e se o IP/Porta estão corretos.`;
           }
      } else {
          lastConnectionError = `Erro ao processar dados do backend: ${msg}`;
      }
  }
};

// --- API Methods ---

export const getLastConnectionError = (): string | null => {
    return lastConnectionError;
};

export const getHosts = async (): Promise<Host[]> => {
  return deepClone(hosts);
};

export const getHostById = async (id: string): Promise<Host | undefined> => {
  const host = hosts.find(h => h.id === id);
  return host ? deepClone(host) : undefined;
};

// Revised to fetch from backend with optional filters
export const getAlerts = async (filters?: { start?: string, end?: string, hostId?: string }): Promise<Alert[]> => {
    const backendUrl = getBackendUrl();
    if (!backendUrl) return [];

    const cleanUrl = backendUrl.endsWith('/') ? backendUrl.slice(0, -1) : backendUrl;

    try {
        const queryParams = new URLSearchParams();
        if (filters?.start) queryParams.append('start_date', filters.start);
        if (filters?.end) queryParams.append('end_date', filters.end);
        if (filters?.hostId) queryParams.append('host_id', filters.hostId);
        
        // Timeout curto para alertas não travarem a UI
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);
        
        const res = await fetch(`${cleanUrl}/api/alerts?${queryParams.toString()}`, {
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (res.ok) {
            const data = await res.json();
            // Transform DB rows to Alert type
            return data.map((row: any) => ({
                id: row.id,
                hostId: row.host_id,
                hostname: row.hostname || 'Desconhecido',
                severity: row.severity,
                message: row.message,
                timestamp: new Date(row.timestamp).getTime(),
                resolved: row.resolved,
                resolvedAt: row.resolved_at ? new Date(row.resolved_at).getTime() : undefined
            }));
        }
    } catch(e: any) {
        // Evita spam no console se for apenas erro de conexão (backend offline)
        if (e.name !== 'AbortError' && e.message !== 'Failed to fetch') {
             console.warn("Erro ao buscar alertas (ignorado):", e.message);
        }
    }
    return [];
};

export const addHost = async (hostData?: Partial<Host>): Promise<void> => {
  console.warn("addHost ignorado: Em modo produção, use o Agente para registrar hosts.");
};

export const updateHost = async (id: string, hostData: Partial<Host>): Promise<void> => {
    const index = hosts.findIndex(h => h.id === id);
    if (index !== -1) {
        hosts[index] = { ...hosts[index], ...hostData };
    }
};
