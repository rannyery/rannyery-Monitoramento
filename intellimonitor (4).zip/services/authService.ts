
import { User } from '../types';
import { getBackendUrl, syncLocalConfigWithBackend } from './mockData';

export const login = async (username: string, password: string): Promise<User> => {
  const backendUrl = getBackendUrl();
  
  try {
    // Garante que não há barra no final e remove espaços
    const sanitizedUrl = backendUrl.endsWith('/') ? backendUrl.slice(0, -1) : backendUrl;

    const response = await fetch(`${sanitizedUrl}/api/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    // Check content type before parsing JSON to avoid "Unexpected token <"
    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        console.error("Resposta inválida do backend (HTML/Texto):", text.substring(0, 150));
        throw new Error(`A URL do backend parece estar incorreta ou o servidor não está rodando. Recebido HTML em vez de JSON. (URL: ${sanitizedUrl})`);
    }

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Credenciais inválidas');
    }

    // A resposta do backend agora deve ser o objeto User completo com o token
    const user: User = data;
    
    // Normaliza o role para lowercase para facilitar comparações
    if (user.role) user.role = user.role.toLowerCase();

    localStorage.setItem('intelli_user', JSON.stringify(user));
    
    // SUCESSO! Agora sincroniza a configuração local com a do banco de dados.
    // Isso garante que se o IP do banco mudou, o navegador é atualizado permanentemente.
    await syncLocalConfigWithBackend(sanitizedUrl);

    return user;

  } catch (err: any) {
    if (err.message.includes('Failed to fetch')) {
        throw new Error('Não foi possível conectar ao servidor. Verifique a URL do backend e se ele está online.');
    }
    // Re-throw a mensagem de erro original
    throw err;
  }
};

export const logout = () => {
  localStorage.removeItem('intelli_user');
};

export const getCurrentUser = (): User | null => {
  const stored = localStorage.getItem('intelli_user');
  return stored ? JSON.parse(stored) : null;
};

export const isAuthenticated = (): boolean => {
  return !!getCurrentUser();
};

// --- CONTROLE DE ACESSO (PERMISSÕES) ---

export const getUserRole = (): string => {
    const user = getCurrentUser();
    return user?.role?.toLowerCase() || 'viewer'; // Default seguro
};

export const isAdmin = (): boolean => {
    return getUserRole() === 'admin';
};

export const canEdit = (): boolean => {
    const role = getUserRole();
    return role === 'admin' || role === 'operador';
};

export const hasPermission = (allowedRoles: string[]): boolean => {
    const userRole = getUserRole();
    // Mapeia roles do banco para os permitidos
    // Ex: se o banco retornar 'visualizador', tratamos como 'viewer' se necessário, 
    // ou garantimos que os arrays allowedRoles usem os termos em português também.
    
    // Normalização simples: verifica se a role do usuário está na lista permitida
    return allowedRoles.map(r => r.toLowerCase()).includes(userRole);
};
